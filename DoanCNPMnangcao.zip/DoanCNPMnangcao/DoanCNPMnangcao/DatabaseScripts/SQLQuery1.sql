﻿	--lần 1
	USE master

	CREATE DATABASE FlightReservationDB1;
	GO

	--Chạy lệnh này để có thể hiện thị sau khi select *
	USE FlightReservationDB1;
	
	
	--lần 2
	-- Table: User
	CREATE TABLE [dbo].[User] (
		[UserID] INT IDENTITY(1,1) PRIMARY KEY,
		[Avatar] NVARCHAR(255) DEFAULT '/Images/Avatars/default.png',
		[Username] NVARCHAR(50) NOT NULL,
		[FullName] NVARCHAR(100) NOT NULL,
		[Email] NVARCHAR(100) NOT NULL UNIQUE,
		[Password] NVARCHAR(100) NOT NULL,
		[PhoneNumber] NVARCHAR(15),
		[UserRole] NVARCHAR(20) CHECK ([UserRole] IN ('Admin', 'User')) DEFAULT 'User',
		[CreatedDate] DATETIME DEFAULT GETDATE(),		--Ngày tạo tài khoản
		[UpdatedDate] DATETIME							--Cập nhật lần cuối
	);
	-- Table: FlightList
	CREATE TABLE [dbo].[FlightList] (
		[FlightID] INT IDENTITY(1,1) PRIMARY KEY,		--Mã bay khóa chính
		[FlightNumber] NVARCHAR(20) NOT NULL,			--Số hiệu chuyến bay
		[DepartureAirport] NVARCHAR(100) NOT NULL,		--Tên sân bay đi
		[DepartureCode] NVARCHAR(10) NOT NULL,			--Mã sân bay đi
		[ArrivalAirport] NVARCHAR(100) NOT NULL,		--Tên sân bay đến
		[ArrivalCode] NVARCHAR(10) NOT NULL,			--Mã sân bay đến
		[DepartureTime] DATETIME NOT NULL,				--Giờ đi
		[ArrivalTime] DATETIME NOT NULL,				--Giờ đến(dĩ nhiên là dự kiến)
		[AvailableSeats] INT NOT NULL,					--Còn chỗ ngồi?
		[Price] DECIMAL(18,2) NOT NULL,					--Giá (format trên IDE)
		[CreatedDate] DATETIME DEFAULT GETDATE(),
		[UpdatedDate] DATETIME
	);
	-- Table: Ticket
	CREATE TABLE [dbo].[Ticket] (
		[TicketID] INT IDENTITY(1,1) PRIMARY KEY,		--Mã vé khóa chính
		[UserID] INT ,							--Mã người dùng
		[FlightID] INT NOT NULL,
		[BookingDate] DATETIME ,		--Ngày đặt
		[SeatNumber] NVARCHAR(10) NOT NULL,						--Số hiệu chỗ ngồi
		[TicketType] NVARCHAR(10),
		[TicketPrice] DECIMAL(18,2) NOT NULL,
		[TicketStatus] NVARCHAR(20) CHECK ([TicketStatus] IN ('Booked', 'Cancelled', 'Completed','Queued')) DEFAULT 'Queued',
		[ReturnFlightID] INT,
		FOREIGN KEY (UserID) REFERENCES [dbo].[User]([UserID]),
		FOREIGN KEY (FlightID) REFERENCES [dbo].[FlightList]([FlightID]),
		FOREIGN KEY (ReturnFlightID) REFERENCES [dbo].[FlightList]([FlightID])
	);
	-- Order 
	CREATE TABLE [dbo].[Order] (
		[OrderID] INT IDENTITY(1, 1) PRIMARY KEY,
		[UserID] INT NOT NULL,
		[OrderDate] DATE DEFAULT GETDATE(),
		[TotalAmount] DECIMAL(18, 2) NOT NULL,
		[PaymentStatus] NVARCHAR(20) DEFAULT 'Pending', -- Trạng thái thanh toán(Pending, Paid, Failed)
		[AddressDelivery] NVARCHAR(255) NOT NULL,
		[PaymentMethod] NVARCHAR(50), -- Phương thức thanh toán (e.g., Credit Card, PayPal, Cash)
		[OrderStatus] NVARCHAR(50) DEFAULT 'Pending', -- Trạng thái đơn hàng (Pending, Confirmed, Cancelled, Completed)
		[CreatedDate] DATETIME DEFAULT GETDATE(),
		[UpdatedDate] DATETIME,
		FOREIGN KEY ([UserID]) REFERENCES [dbo].[User]([UserID])
	);
	-- OrderDetail 
	CREATE TABLE [dbo].[OrderDetail] (
		[OrderDetailID] INT IDENTITY(1, 1) PRIMARY KEY,
		[OrderID] INT NOT NULL,
		[TicketID] INT NOT NULL,
		[Quantity] INT NOT NULL DEFAULT 1,
		[UnitPrice] DECIMAL(18, 2) NOT NULL,
		[Discount] DECIMAL(18, 2) DEFAULT 0.00, -- Giảm giá
		[TotalPrice] AS ([Quantity] * [UnitPrice] - [Discount]) PERSISTED, -- Tổng tiền, ko thể tự thêm, là tự tính toán
		[CreatedDate] DATETIME DEFAULT GETDATE(), -- Track time order được khởi tạo
		[UpdatedDate] DATETIME, -- Track time lần cuối  cập nhật
		FOREIGN KEY ([OrderID]) REFERENCES [dbo].[Order]([OrderID]),
		FOREIGN KEY ([TicketID]) REFERENCES [dbo].[Ticket]([TicketID])
	);
	-- Table: Notification
	CREATE TABLE [dbo].[Notification] (
    [NotificationID] INT IDENTITY(1,1) PRIMARY KEY, -- Mã thông báo
    [UserID] INT NOT NULL, -- Mã người dùng liên quan đến thông báo
    [Message] NVARCHAR(500) NOT NULL, -- Nội dung thông báo
    [CreatedDate] DATETIME DEFAULT GETDATE(), -- Ngày tạo thông báo
    [NotificationType] NVARCHAR(50), -- Loại thông báo (e.g., "TicketBooking", "OrderStatus", "FlightReminder")
    [IsRead] BIT DEFAULT 0, -- Trạng thái đọc chưa
    FOREIGN KEY (UserID) REFERENCES [dbo].[User]([UserID]) -- Liên kết với bảng User
   );
   
   CREATE TABLE Feedback (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Content NVARCHAR(MAX),
    CreatedAt DATETIME
  );

	ALTER TABLE Feedback
	ADD UserID INT;	

  ALTER TABLE Feedback
  ADD CONSTRAINT FK_Feedback_User
  FOREIGN KEY (UserID) REFERENCES [User](UserID);

  --lần 3
DECLARE @StartDate DATETIME = '2024-12-01';
DECLARE @EndDate DATETIME = '2024-12-31';
DECLARE @FlightNumber NVARCHAR(20);
DECLARE @DepartureAirport NVARCHAR(100);
DECLARE @DepartureCode NVARCHAR(10);
DECLARE @ArrivalAirport NVARCHAR(100);
DECLARE @ArrivalCode NVARCHAR(10);
DECLARE @AvailableSeats INT = 100;  -- Số ghế mặc định
DECLARE @Price DECIMAL(18,2);  -- Giá vé ngẫu nhiên
DECLARE @FlightCounter INT = 1001;  -- Đếm mã chuyến bay bắt đầu từ FL1001

-- Mảng các điểm đến và điểm khởi hành
DECLARE @Destinations TABLE (Departure NVARCHAR(100), Arrival NVARCHAR(100), DepartureCode NVARCHAR(10), ArrivalCode NVARCHAR(10));
INSERT INTO @Destinations (Departure, Arrival, DepartureCode, ArrivalCode)
VALUES
    (N'Hồ Chí Minh', N'Hà Nội', 'HCM', 'HAN'),  -- HCM -> Hà Nội
    (N'Hà Nội', N'Hồ Chí Minh', 'HAN', 'HCM'),  -- Hà Nội -> HCM
    (N'Đà Nẵng', N'Hà Nội', 'DAN', 'HAN'),      -- Đà Nẵng -> Hà Nội
    (N'Hà Nội', N'Đà Nẵng', 'HAN', 'DAN'),      -- Hà Nội -> Đà Nẵng
    (N'Hồ Chí Minh', N'Phú Quốc', 'HCM', 'PHU'), -- HCM -> Phú Quốc
    (N'Phú Quốc', N'Hồ Chí Minh', 'PHU', 'HCM'), -- Phú Quốc -> HCM
    (N'Hồ Chí Minh', N'Nha Trang', 'HCM', 'NHA'), -- HCM -> Nha Trang
    (N'Nha Trang', N'Hồ Chí Minh', 'NHA', 'HCM'); -- Nha Trang -> HCM

-- Vòng lặp tạo các chuyến bay
WHILE @StartDate <= @EndDate
BEGIN
    -- Tạo 10 chuyến bay cố định từ Hồ Chí Minh mỗi ngày
    DECLARE @i INT = 1;
    WHILE @i <= 10
    BEGIN
        -- Lấy mã chuyến bay tăng dần
        SET @FlightNumber = 'FL' + CAST(@FlightCounter AS NVARCHAR);
        SET @FlightCounter = @FlightCounter + 1;

        -- Sinh giá vé ngẫu nhiên từ 120 đến 210
        SET @Price = (120 + (FLOOR(RAND() * 5) * 30));  -- Giá vé: 120, 150, 175, 210

        -- Tạo chuyến bay từ HCM đến HAN
        INSERT INTO [dbo].[FlightList] (
            [FlightNumber], 
            [DepartureAirport], 
            [DepartureCode], 
            [ArrivalAirport], 
            [ArrivalCode], 
            [DepartureTime], 
            [ArrivalTime], 
            [AvailableSeats], 
            [Price], 
            [CreatedDate]
        )
        VALUES (
            @FlightNumber,
            N'Hồ Chí Minh',
            'HCM',
            N'Hà Nội',
            'HAN',
            DATEADD(HOUR, 7 + FLOOR(RAND() * 5), @StartDate),  -- Giờ khởi hành ngẫu nhiên trong khoảng 7-12 giờ
            DATEADD(HOUR, 9 + FLOOR(RAND() * 5), @StartDate),  -- Giờ đến ngẫu nhiên trong khoảng 9-14 giờ
            @AvailableSeats,
            @Price,
            GETDATE()
        );

        SET @i = @i + 1;
    END

    -- Tạo 5-6 chuyến bay ngẫu nhiên mỗi ngày
    DECLARE @j INT = 1;
    WHILE @j <= (5 + FLOOR(RAND() * 2))  -- Random 5-6 chuyến bay
    BEGIN
        -- Random chọn điểm khởi hành và điểm đến
        DECLARE @RandomIndex INT = 1 + FLOOR(RAND() * 8);

        -- Sử dụng CTE để chọn điểm ngẫu nhiên từ danh sách
        WITH RandomDestinations AS (
            SELECT 
                Departure, 
                Arrival, 
                DepartureCode, 
                ArrivalCode,
                ROW_NUMBER() OVER (ORDER BY NEWID()) AS RowNum
            FROM @Destinations
        )
        SELECT 
            @DepartureAirport = Departure, 
            @ArrivalAirport = Arrival, 
            @DepartureCode = DepartureCode, 
            @ArrivalCode = ArrivalCode
        FROM RandomDestinations
        WHERE RowNum = @RandomIndex;

        -- Lấy mã chuyến bay tăng dần
        SET @FlightNumber = 'FL' + CAST(@FlightCounter AS NVARCHAR);
        SET @FlightCounter = @FlightCounter + 1;

        -- Sinh giá vé ngẫu nhiên từ 120 đến 210
        SET @Price = (120 + (FLOOR(RAND() * 5) * 30));  -- Giá vé: 120, 150, 175, 210

        -- Tạo chuyến bay ngẫu nhiên
        INSERT INTO [dbo].[FlightList] (
            [FlightNumber], 
            [DepartureAirport], 
            [DepartureCode], 
            [ArrivalAirport], 
            [ArrivalCode], 
            [DepartureTime], 
            [ArrivalTime], 
            [AvailableSeats], 
            [Price], 
            [CreatedDate]
        )
        VALUES (
            @FlightNumber,
            @DepartureAirport,
            @DepartureCode,
            @ArrivalAirport,
            @ArrivalCode,
            DATEADD(HOUR, 7 + FLOOR(RAND() * 5), @StartDate),  -- Giờ khởi hành ngẫu nhiên trong khoảng 7-12 giờ
            DATEADD(HOUR, 9 + FLOOR(RAND() * 5), @StartDate),  -- Giờ đến ngẫu nhiên trong khoảng 9-14 giờ
            @AvailableSeats,
            @Price,
            GETDATE()
        );

        SET @j = @j + 1;
    END

    -- Tiến đến ngày tiếp theo
    SET @StartDate = DATEADD(DAY, 1, @StartDate);
END


-- phụ thêm


-- Check bảng
SELECT * FROM [dbo].[User];
SELECT * FROM [dbo].[FlightList];
SELECT * FROM [dbo].[Ticket];
SELECT * FROM [dbo].[Order];
SELECT * FROM [dbo].[OrderDetail];
SELECT * FROM [dbo].[Notification];

WITH CTE AS (
    SELECT 
        *, ROW_NUMBER() OVER (PARTITION BY FlightNumber, DepartureTime, ArrivalTime ORDER BY FlightID) AS RowNum
    FROM 
        [dbo].[FlightList]
)
DELETE FROM CTE WHERE RowNum > 1;

SELECT 
    OBJECT_NAME(fk.parent_object_id) AS TableName,
    COL_NAME(fkc.parent_object_id, fkc.parent_column_id) AS ColumnName,
    OBJECT_NAME(fk.referenced_object_id) AS ReferencedTable,
    COL_NAME(fkc.referenced_object_id, fkc.referenced_column_id) AS ReferencedColumn
FROM 
    sys.foreign_keys AS fk
INNER JOIN 
    sys.foreign_key_columns AS fkc
    ON fk.object_id = fkc.constraint_object_id;
--Thử nghiệm: lấy tin nhắn chưa đọc
CREATE PROCEDURE GetUnreadNotifications
    @UserID INT
AS
BEGIN
    SELECT [NotificationID], [UserID], [Message], [IsRead], [CreatedDate]
    FROM [dbo].[Notification]
    WHERE UserID = @UserID AND IsRead = 0
    ORDER BY CreatedDate DESC;
END

--Danger zone! để đây thôi
ALTER AUTHORIZATION ON DATABASE::FlightReservationDB TO sa;


ALTER DATABASE FlightReservationDB SET OFFLINE WITH ROLLBACK IMMEDIATE
DROP DATABASE FlightReservationDB
--FlightReservationDBEntities


-- Ví dụ: xóa User có UserID = 1

-- B1: Xóa OrderDetail liên quan
DELETE FROM OrderDetail 
WHERE OrderID IN (SELECT OrderID FROM [Order] WHERE UserID = 9);

-- B2: Xóa Order liên quan
DELETE FROM [Order] WHERE UserID = 9;

-- B3: Xóa Ticket liên quan
DELETE FROM Ticket WHERE UserID = 9;

-- B4: Xóa Notification liên quan
DELETE FROM Notification WHERE UserID = 9;

-- B5: Cuối cùng xóa User
DELETE FROM [User] WHERE UserID = 9;

select * from [User]

UPDATE [User]
SET UserRole = 'Admin'
WHERE UserID = 11;
