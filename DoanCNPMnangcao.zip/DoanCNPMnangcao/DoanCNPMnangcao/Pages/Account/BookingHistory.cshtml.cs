﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using DoanCNPMnangcao.Data;
using DoanCNPMnangcao.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace FlightReservationRazor.Pages.Account
{
    [Authorize] // Chỉ người đã đăng nhập mới vào được
    public class BookingHistoryModel : PageModel
    {
        private readonly FlightReservationDbContext _context;

        public BookingHistoryModel(FlightReservationDbContext context)
        {
            _context = context;
        }

        // Danh sách vé để hiển thị
        public List<Ticket> BookedTickets { get; set; } = new List<Ticket>();

        public async Task<IActionResult> OnGetAsync()
        {
            var userIdString = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userIdString) || !int.TryParse(userIdString, out int userId))
            {
                return RedirectToPage("/Login"); // Không tìm thấy User, bắt đăng nhập lại
            }

            // Truy vấn tất cả vé của User này
            // Bao gồm thông tin Chuyến đi và Chuyến về
            BookedTickets = await _context.Tickets
                .Where(t => t.UserID == userId)
                .Include(t => t.Flight) // Lấy thông tin chuyến đi
                .Include(t => t.ReturnFlight) // Lấy thông tin chuyến về (nếu có)
                .OrderByDescending(t => t.BookingDate) // Sắp xếp vé mới nhất lên đầu
                .ToListAsync();

            return Page();
        }
    }
}
