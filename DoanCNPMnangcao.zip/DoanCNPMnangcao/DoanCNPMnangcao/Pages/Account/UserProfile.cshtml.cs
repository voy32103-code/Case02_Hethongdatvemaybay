﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Security.Claims;
using System.Threading.Tasks;
using DoanCNPMnangcao.Data;
using DoanCNPMnangcao.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace FlightReservationRazor.Pages.Account
{
    [Authorize] // Chỉ người đã đăng nhập mới vào được
    public class UserProfileModel : PageModel
    {
        private readonly FlightReservationDbContext _context;

        public UserProfileModel(FlightReservationDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public InputModel Input { get; set; } = new InputModel();

        [TempData]
        public string? SuccessMessage { get; set; }

        public User? CurrentUser { get; set; }

        public class InputModel
        {
            [Required(ErrorMessage = "Họ tên là bắt buộc.")]
            [Display(Name = "Họ và tên")]
            public string FullName { get; set; } = string.Empty;

            [Phone(ErrorMessage = "Số điện thoại không hợp lệ.")]
            [Display(Name = "Số điện thoại")]
            public string? PhoneNumber { get; set; }
        }

        private async Task<User?> LoadCurrentUserAsync()
        {
            var userIdString = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userIdString) || !int.TryParse(userIdString, out int userId))
            {
                return null;
            }
            return await _context.Users.FindAsync(userId);
        }

        public async Task<IActionResult> OnGetAsync()
        {
            CurrentUser = await LoadCurrentUserAsync();
            if (CurrentUser == null)
            {
                // Đăng xuất nếu không tìm thấy user
                return RedirectToPage("/Logout");
            }

            // Điền dữ liệu vào form
            Input.FullName = CurrentUser.FullName;
            Input.PhoneNumber = CurrentUser.PhoneNumber;

            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            CurrentUser = await LoadCurrentUserAsync();
            if (CurrentUser == null)
            {
                return RedirectToPage("/Logout");
            }

            if (!ModelState.IsValid)
            {
                return Page();
            }

            // Cập nhật thông tin
            CurrentUser.FullName = Input.FullName;
            CurrentUser.PhoneNumber = Input.PhoneNumber;
            CurrentUser.UpdatedDate = DateTime.UtcNow; // Cập nhật thời gian

            try
            {
                _context.Users.Update(CurrentUser);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                // Xử lý lỗi nếu có ai đó cập nhật cùng lúc
                ModelState.AddModelError(string.Empty, "Không thể lưu thay đổi. Vui lòng thử lại.");
                return Page();
            }

            SuccessMessage = "Cập nhật thông tin thành công!";
            return RedirectToPage(); // Tải lại trang
        }
    }
}
