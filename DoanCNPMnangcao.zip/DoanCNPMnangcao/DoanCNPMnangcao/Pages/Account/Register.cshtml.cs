﻿using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using DoanCNPMnangcao.Data;
using DoanCNPMnangcao.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System; // Thêm
using System.Collections.Generic; // Thêm
using System.Linq; // Thêm

namespace FlightReservationRazor.Pages.Account // Đảm bảo namespace đúng
{
    public class RegisterModel : PageModel
    {
        private readonly FlightReservationDbContext _context;

        public RegisterModel(FlightReservationDbContext context)
        {
            _context = context;
        }

        // --- Thuộc tính BindProperty khớp với asp-for trong HTML ---
        [BindProperty]
        [Required(ErrorMessage = "Vui lòng nhập Email.")]
        [EmailAddress(ErrorMessage = "Email không đúng định dạng.")]
        public string Email { get; set; } = string.Empty;

        [BindProperty]
        [Required(ErrorMessage = "Vui lòng nhập Tên đăng nhập.")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Tên đăng nhập phải từ 3 đến 50 ký tự.")]
        public string Username { get; set; } = string.Empty;

        // 🚀 THÊM TRƯỜNG FULLNAME (Cần thiết cho Claim "FullName") 🚀
        [BindProperty]
        [Required(ErrorMessage = "Vui lòng nhập Họ Tên.")]
        [StringLength(100)]
        [Display(Name = "Họ và Tên")]
        public string FullName { get; set; } = string.Empty;

        [BindProperty]
        [Required(ErrorMessage = "Vui lòng nhập Mật khẩu.")]
        [StringLength(100, MinimumLength = 6, ErrorMessage = "Mật khẩu phải có ít nhất 6 ký tự.")]
        [DataType(DataType.Password)]
        public string Password { get; set; } = string.Empty;

        [BindProperty]
        [Required(ErrorMessage = "Vui lòng xác nhận Mật khẩu.")]
        [DataType(DataType.Password)]
        [Display(Name = "Xác nhận Mật khẩu")] // Sửa lỗi chính tả
        [Compare("Password", ErrorMessage = "Mật khẩu và Xác nhận mật khẩu không khớp.")]
        public string ConfirmPassword { get; set; } = string.Empty;

        // --- Thuộc tính hiển thị thông báo ---
        public string? Message { get; set; }
        public bool IsSuccess { get; set; } = false;

        public void OnGet()
        {
            // Chỉ hiển thị trang
        }

        public async Task<IActionResult> OnPostAsync(string? returnUrl = null)
        {
            returnUrl ??= Url.Content("~/");

            if (!ModelState.IsValid)
            {
                IsSuccess = false;
                // Message = "Dữ liệu nhập không hợp lệ. Vui lòng kiểm tra lại."; // Không cần, validation tự hiển thị
                return Page(); // Hiển thị lại form với lỗi validation
            }

            // Kiểm tra xem Username hoặc Email đã tồn tại chưa
            var existingUser = await _context.Users
                .AnyAsync(u => u.Username == Username || u.Email == Email);

            if (existingUser)
            {
                IsSuccess = false;
                Message = "Tên đăng nhập hoặc Email đã tồn tại.";
                return Page();
            }

            // ⚠️ CẢNH BÁO BẢO MẬT: Mật khẩu đang được lưu dưới dạng plain text.
            var user = new User
            {
                Username = Username,
                Email = Email,
                Password = Password, // CẦN PHẢI HASH
                FullName = FullName, // 👈 Đã sử dụng FullName từ form
                UserRole = "User", // Mặc định là User
                IsActive = true // 👈 ĐẢM BẢO TÀI KHOẢN MỚI ĐƯỢC KÍCH HOẠT
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            // Đặt thông báo thành công và chuyển hướng đến trang Đăng nhập
            TempData["SuccessMessage"] = "Đăng ký tài khoản thành công! Vui lòng đăng nhập.";
            return RedirectToPage("/Account/Login", new { returnUrl }); // Sửa đường dẫn
        }
    }
}