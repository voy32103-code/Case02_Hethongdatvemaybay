﻿using System;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using DoanCNPMnangcao.Data;
using DoanCNPMnangcao.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace FlightReservationRazor.Pages.Account // Đảm bảo namespace đúng
{
    [Authorize] // Yêu cầu đăng nhập
    public class TicketDetailModel : PageModel
    {
        private readonly FlightReservationDbContext _context;

        public TicketDetailModel(FlightReservationDbContext context)
        {
            _context = context;
        }

        [BindProperty(SupportsGet = true)]
        public int TicketId { get; set; }

        public Ticket? Ticket { get; set; }
        public Order? Order { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            if (TicketId <= 0)
            {
                return RedirectToPage("/Account/BookingHistory");
            }

            var userIdString = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (!int.TryParse(userIdString, out int currentUserId))
            {
                return RedirectToPage("/Account/Login");
            }

            // Lấy chi tiết vé (Ticket) và thông tin chuyến bay (Flight)
            Ticket = await _context.Tickets
                .Include(t => t.Flight)
                .Include(t => t.ReturnFlight) // Nếu có vé khứ hồi
                .FirstOrDefaultAsync(t => t.TicketID == TicketId && t.UserID == currentUserId);

            if (Ticket == null)
            {
                TempData["ErrorMessage"] = "Không tìm thấy vé hoặc vé không thuộc tài khoản của bạn.";
                return RedirectToPage("/Account/BookingHistory");
            }

            // Lấy thông tin Order (Đơn hàng)
            Order = await _context.Orders
                .FirstOrDefaultAsync(o =>
                    o.UserID == currentUserId &&
                    o.TotalAmount == Ticket.TicketPrice // Giả định Order TotalAmount khớp với TicketPrice
                );

            // LƯU Ý: Đây là phương pháp lấy Order tạm thời. Tốt nhất Order và Ticket nên liên kết 1-1 bằng OrderDetail.

            return Page();
        }
    }
}