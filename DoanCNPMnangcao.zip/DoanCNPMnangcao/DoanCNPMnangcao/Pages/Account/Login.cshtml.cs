﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Security.Claims;
using System.Threading.Tasks;
using DoanCNPMnangcao.Data;
using DoanCNPMnangcao.Models; // Đảm bảo using Model
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace FlightReservationRazor.Pages.Account // Đảm bảo namespace đúng
{
    public class LoginModel : PageModel
    {
        private readonly FlightReservationDbContext _context;

        public LoginModel(FlightReservationDbContext context)
        {
            _context = context;
        }

        // --- Thuộc tính BindProperty khớp với asp-for ---
        [BindProperty]
        [Required(ErrorMessage = "Vui lòng nhập Tên đăng nhập.")]
        public string Username { get; set; } = string.Empty;

        [BindProperty]
        [Required(ErrorMessage = "Vui lòng nhập Mật khẩu.")]
        [DataType(DataType.Password)]
        public string Password { get; set; } = string.Empty;

        [BindProperty]
        public bool RememberMe { get; set; }

        // --- Thuộc tính hiển thị thông báo ---
        public string? Message { get; set; }

        public async Task OnGetAsync(string? returnUrl = null)
        {
            // Hiển thị thông báo nếu được redirect từ trang Đăng ký
            if (TempData["SuccessMessage"] != null)
            {
                Message = TempData["SuccessMessage"]?.ToString();
            }

            // Đăng xuất người dùng hiện tại (nếu có)
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        }

        public async Task<IActionResult> OnPostAsync(string? returnUrl = null)
        {
            returnUrl ??= Url.Content("~/"); // Trang mặc định sau khi đăng nhập

            if (!ModelState.IsValid)
            {
                Message = "Tên đăng nhập và Mật khẩu là bắt buộc.";
                return Page();
            }

            // ⚠️ CẢNH BÁO BẢO MẬT: So sánh plain text.
            // 🚀 ĐÃ THÊM ĐIỀU KIỆN IsActive == true 🚀
            var user = await _context.Users
                .FirstOrDefaultAsync(u =>
                    (u.Username == Username || u.Email == Username) &&
                    u.Password == Password &&
                    u.IsActive == true // Chỉ cho phép user đang hoạt động đăng nhập
                );

            if (user == null)
            {
                // Thông báo chung chung để bảo mật
                Message = "Tài khoản hoặc mật khẩu không chính xác, hoặc tài khoản đã bị khóa.";
                return Page();
            }

            // Tạo danh sách Claims (thông tin định danh)
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, user.Username), // Tên hiển thị (Chào, ...)
                new Claim(ClaimTypes.Email, user.Email),
                new Claim(ClaimTypes.NameIdentifier, user.UserID.ToString()), // ID người dùng
                new Claim("FullName", user.FullName), // Claim tùy chỉnh
                new Claim(ClaimTypes.Role, user.UserRole) // Gán Role (Admin/User)
            };

            var claimsIdentity = new ClaimsIdentity(
                claims, CookieAuthenticationDefaults.AuthenticationScheme);

            var authProperties = new AuthenticationProperties
            {
                IsPersistent = RememberMe, // Lưu cookie lâu dài nếu người dùng chọn "Ghi nhớ"
                ExpiresUtc = RememberMe ? DateTimeOffset.UtcNow.AddDays(30) : (DateTimeOffset?)null
            };

            // Đăng nhập người dùng (tạo cookie)
            await HttpContext.SignInAsync(
                CookieAuthenticationDefaults.AuthenticationScheme,
                new ClaimsPrincipal(claimsIdentity),
                authProperties);

            // Chuyển hướng dựa trên Role
            if (user.UserRole == "Admin")
            {
                return LocalRedirect(Url.Content("~/Admin/AdminDashboard")); // Về trang Admin
            }

            return LocalRedirect(returnUrl); // Về trang chủ hoặc trang trước đó
        }
    }
}