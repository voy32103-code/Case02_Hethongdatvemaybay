﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

namespace FlightReservationRazor.Pages.Account
{
    public class ForgotPasswordModel : PageModel
    {
        [BindProperty]
        [Required(ErrorMessage = "Vui lòng nhập Email hoặc Tên đăng nhập.")]
        public string? Identifier { get; set; }
        public string? Message { get; set; }
        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                Message = "Vui lòng cung cấp Email hoặc Tên đăng nhập hợp lệ.";
                return Page();
            }

            // Logic giả lập: Tìm người dùng và gửi email/thông báo

            Message = $"Hướng dẫn khôi phục mật khẩu đã được gửi đến {Identifier}. Vui lòng kiểm tra hộp thư.";

            // Sau khi gửi, chúng ta có thể chuyển hướng về trang Login
            // return RedirectToPage("/Login"); 

            return Page(); // Tạm thời ở lại trang để hiển thị thông báo
        }
    }
}