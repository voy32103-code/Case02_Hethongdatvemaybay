﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using DoanCNPMnangcao.Data;
using DoanCNPMnangcao.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering; // Cho SelectListItem
using Microsoft.EntityFrameworkCore;

namespace FlightReservationRazor.Pages.Admin // Đảm bảo namespace đúng
{
    [Authorize(Roles = "Admin")]
    public class AddUserModel : PageModel
    {
        private readonly FlightReservationDbContext _context;

        public AddUserModel(FlightReservationDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public InputModel Input { get; set; } = new InputModel();

        // Cần thiết để tạo dropdown Vai trò (Admin/User)
        public List<SelectListItem> RoleOptions { get; set; } = new List<SelectListItem>();

        public class InputModel
        {
            [Required(ErrorMessage = "Tên đăng nhập là bắt buộc.")]
            [StringLength(50, MinimumLength = 3)]
            public string Username { get; set; } = string.Empty;

            [Required(ErrorMessage = "Họ tên là bắt buộc.")]
            public string FullName { get; set; } = string.Empty;

            [Required(ErrorMessage = "Email là bắt buộc.")]
            [EmailAddress]
            public string Email { get; set; } = string.Empty;

            [Required(ErrorMessage = "Mật khẩu là bắt buộc.")]
            [DataType(DataType.Password)]
            [StringLength(100, MinimumLength = 6, ErrorMessage = "Mật khẩu phải có ít nhất 6 ký tự.")]
            public string Password { get; set; } = string.Empty;

            [Required(ErrorMessage = "Vai trò là bắt buộc.")]
            public string UserRole { get; set; } = "User";
        }

        private void PopulateRoleOptions()
        {
            RoleOptions = new List<SelectListItem>
            {
                new SelectListItem { Value = "User", Text = "User (Người dùng)" },
                new SelectListItem { Value = "Admin", Text = "Admin (Quản trị viên)" }
            };
        }

        public void OnGet()
        {
            PopulateRoleOptions(); // Khởi tạo dropdown khi tải trang
        }

        public async Task<IActionResult> OnPostAsync()
        {
            // Kiểm tra validation cơ bản của Model
            if (!ModelState.IsValid)
            {
                PopulateRoleOptions();
                return Page();
            }

            // Kiểm tra trùng lặp
            var existingUser = await _context.Users
                .AnyAsync(u => u.Username == Input.Username || u.Email == Input.Email);

            if (existingUser)
            {
                ModelState.AddModelError(string.Empty, "Tên đăng nhập hoặc Email đã tồn tại.");
                PopulateRoleOptions();
                return Page();
            }

            var user = new User
            {
                Username = Input.Username,
                FullName = Input.FullName,
                Email = Input.Email,
                Password = Input.Password, // ⚠️ LƯU Ý: CẦN HASH MẬT KHẨU
                UserRole = Input.UserRole,
                IsActive = true, // Áp dụng Soft Delete
                CreatedDate = DateTime.UtcNow
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = $"Đã tạo thành công người dùng {user.Username} ({user.UserRole}).";
            return RedirectToPage("/Admin/AdminDashboard", new { ActiveTab = "users" });
        }
    }
}