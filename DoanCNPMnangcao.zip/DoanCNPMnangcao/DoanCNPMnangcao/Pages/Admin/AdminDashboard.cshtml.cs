﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DoanCNPMnangcao.Data;
using DoanCNPMnangcao.Models;
using System;
using Microsoft.AspNetCore.Authorization;
using System.Text;

namespace DoanCNPMnangcao.Pages.Admin // Đảm bảo namespace đúng
{
    [Authorize(Roles = "Admin")]
    public class AdminDashboardModel : PageModel
    {
        private readonly FlightReservationDbContext _context;

        public AdminDashboardModel(FlightReservationDbContext context)
        {
            _context = context;
        }

        // --- Dữ liệu thống kê & % thay đổi ---
        public int TotalUsers { get; set; }
        public int OrdersProcessing { get; set; }
        public int TicketsSoldThisMonth { get; set; }
        public decimal MonthlyRevenue { get; set; }
        public double? TotalUsersChangePercentage { get; set; }
        public double? OrdersProcessingChangePercentage { get; set; }
        public double? TicketsSoldChangePercentage { get; set; }
        public double? MonthlyRevenueChangePercentage { get; set; }
        public List<ActivityItem> RecentActivities { get; set; } = new List<ActivityItem>();
        public List<Feedback> Feedbacks { get; set; } = new List<Feedback>();
        // --- Dữ liệu cho các Tab ---
        public List<FlightList> Flights { get; set; } = new List<FlightList>();
        public List<Ticket> Tickets { get; set; } = new List<Ticket>();
        public List<User> Users { get; set; } = new List<User>();

        // --- Thuộc tính Bộ lọc & Tab ---
        [BindProperty(SupportsGet = true)]
        public string? SearchTerm { get; set; }
        [BindProperty(SupportsGet = true)]
        public DateTime? DateFilter { get; set; }
        [BindProperty(SupportsGet = true)]
        public string ActiveTab { get; set; } = "dashboard";

        public async Task OnGetAsync()
        {
            var today = DateTime.UtcNow;
            var startOfThisMonth = new DateTime(today.Year, today.Month, 1);
            var startOfLastMonth = startOfThisMonth.AddMonths(-1);
            var startOfTodayDate = today.Date;
            var startOfPreviousDayDate = startOfTodayDate.AddDays(-1);

            // --- Tính toán dữ liệu thống kê ---
            TotalUsers = await _context.Users.CountAsync();
            OrdersProcessing = await _context.Orders.CountAsync(o => o.OrderDate >= startOfTodayDate && o.OrderDate < startOfTodayDate.AddDays(1) && (o.OrderStatus == "Pending" || o.OrderStatus == "Confirmed"));
            TicketsSoldThisMonth = await _context.Tickets.CountAsync(t => t.BookingDate.HasValue && t.BookingDate.Value >= startOfThisMonth && t.BookingDate.Value < startOfThisMonth.AddMonths(1) && (t.TicketStatus == "Booked" || t.TicketStatus == "Completed"));
            MonthlyRevenue = await _context.OrderDetails.Where(od => od.Order.OrderDate >= startOfThisMonth && od.Order.OrderDate < startOfThisMonth.AddMonths(1) && od.Order.PaymentStatus == "Paid").SumAsync(od => od.TotalPrice);
            var totalUsersAtStartOfMonth = await _context.Users.CountAsync(u => u.CreatedDate < startOfThisMonth);
            var ordersProcessedYesterday = await _context.Orders.CountAsync(o => o.OrderDate >= startOfPreviousDayDate && o.OrderDate < startOfTodayDate && (o.OrderStatus == "Pending" || o.OrderStatus == "Confirmed"));
            var ticketsSoldLastMonth = await _context.Tickets.CountAsync(t => t.BookingDate.HasValue && t.BookingDate.Value >= startOfLastMonth && t.BookingDate.Value < startOfThisMonth && (t.TicketStatus == "Booked" || t.TicketStatus == "Completed"));
            var lastMonthRevenue = await _context.OrderDetails.Where(od => od.Order.OrderDate >= startOfLastMonth && od.Order.OrderDate < startOfThisMonth && od.Order.PaymentStatus == "Paid").SumAsync(od => od.TotalPrice);
            TotalUsersChangePercentage = CalculatePercentageChange(TotalUsers, totalUsersAtStartOfMonth);
            OrdersProcessingChangePercentage = CalculatePercentageChange(OrdersProcessing, ordersProcessedYesterday);
            TicketsSoldChangePercentage = CalculatePercentageChange(TicketsSoldThisMonth, ticketsSoldLastMonth);
            MonthlyRevenueChangePercentage = CalculatePercentageChange((double)MonthlyRevenue, (double)lastMonthRevenue);

            // --- Lấy Hoạt động gần đây ---
            var recentNotifications = await _context.Notifications.Include(n => n.User).OrderByDescending(n => n.CreatedDate).Take(5).ToListAsync();
            RecentActivities = recentNotifications.Select(n => new ActivityItem { Type = GetActivityType(n.NotificationType), Title = n.NotificationType ?? "Thông báo", Description = n.Message, TimeAgo = GetTimeAgo(n.CreatedDate) }).ToList();

            // --- Lấy Danh sách Chuyến bay (với bộ lọc) ---
            var flightsQuery = _context.FlightLists.AsQueryable();
            if (!string.IsNullOrEmpty(SearchTerm))
            {
                var lowerSearchTerm = SearchTerm.ToLower();
                flightsQuery = flightsQuery.Where(f =>
                    f.FlightNumber.ToLower().Contains(lowerSearchTerm) ||
                    f.DepartureAirport.ToLower().Contains(lowerSearchTerm) ||
                    f.ArrivalAirport.ToLower().Contains(lowerSearchTerm) ||
                    f.DepartureCode.ToLower().Contains(lowerSearchTerm) ||
                    f.ArrivalCode.ToLower().Contains(lowerSearchTerm)
                );
            }
            if (DateFilter.HasValue)
            {
                var filterDate = DateFilter.Value.Date;
                flightsQuery = flightsQuery.Where(f => f.DepartureTime.Date == filterDate);
            }
            Flights = await flightsQuery
                            .OrderByDescending(f => f.DepartureTime)
                            .ToListAsync();

            // --- Lấy Danh sách Vé ---
            Tickets = await _context.Tickets.Include(t => t.User).Include(t => t.Flight).OrderByDescending(t => t.BookingDate ?? DateTime.MinValue).Take(20).ToListAsync();

            // --- LẤY DANH SÁCH NGƯỜI DÙNG ---
            Users = await _context.Users
                  .Where(u => u.IsActive == true) // Chỉ lấy user chưa bị "xóa"
                  .OrderByDescending(u => u.CreatedDate)
                  .ToListAsync();
            Feedbacks = await _context.Feedbacks
                            .Include(f => f.User) // Lấy thông tin người gửi
                            .OrderByDescending(f => f.CreatedDate)
                            .ToListAsync();
        }

        // --- Handler Xóa User ---

        public async Task<IActionResult> OnPostDeleteUserAsync(int userId)
        {
            if (userId <= 0) { /* ... (báo lỗi) ... */ }
            var user = await _context.Users.FindAsync(userId);
            if (user == null) { /* ... (báo lỗi) ... */ }
            if (user.UserRole == "Admin" && await _context.Users.CountAsync(u => u.UserRole == "Admin" && u.IsActive == true) <= 1)
            {
                TempData["ErrorMessage"] = "Không thể xóa Quản trị viên cuối cùng đang hoạt động.";
                return RedirectToPage(new { ActiveTab = "users" });
            }

            try
            {
                
                user.IsActive = false; // <<< SỬA Ở ĐÂY
                user.UpdatedDate = DateTime.UtcNow;
                _context.Users.Update(user); // Đổi từ Remove sang Update

                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = $"Đã vô hiệu hóa người dùng {user.Username}.";
            }
            catch (Exception) // Bỏ 'ex'
            {
                TempData["ErrorMessage"] = "Đã xảy ra lỗi không mong muốn.";
            }

            return RedirectToPage(new { ActiveTab = "users" });
        }
        public async Task<IActionResult> OnPostDeleteFeedbackAsync(int feedbackId)
        {
            if (feedbackId <= 0)
            {
                TempData["ErrorMessage"] = "ID Đánh giá không hợp lệ.";
                return RedirectToPage(new { ActiveTab = "reviews" });
            }

            var feedback = await _context.Feedbacks.FindAsync(feedbackId);
            if (feedback == null)
            {
                TempData["ErrorMessage"] = "Không tìm thấy đánh giá này.";
                return RedirectToPage(new { ActiveTab = "reviews" });
            }

            try
            {
                _context.Feedbacks.Remove(feedback); // Xóa trực tiếp
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Đã xóa đánh giá thành công.";
            }
            catch (Exception) // Bỏ 'ex'
            {
                TempData["ErrorMessage"] = "Đã xảy ra lỗi không mong muốn khi xóa đánh giá.";
            }

            return RedirectToPage(new { ActiveTab = "reviews" }); // Tải lại trang với tab reviews
        }
        public async Task<IActionResult> OnGetGenerateReportAsync()
        {
            try
            {
                // 1. Lấy dữ liệu doanh thu (chỉ lấy các đơn đã thanh toán)
                var paidOrders = await _context.Orders
                    .Where(o => o.PaymentStatus == "Paid")
                    .Include(o => o.User) // Lấy thông tin người đặt
                    .ToListAsync();

                var totalRevenue = paidOrders.Sum(o => o.TotalAmount);
                var totalOrders = paidOrders.Count;

                // 2. Tạo nội dung file text
                var reportContent = new StringBuilder();
                reportContent.AppendLine("=======================================");
                reportContent.AppendLine("    BÁO CÁO DOANH THU - HUNGYENAIRLINE   ");
                reportContent.AppendLine("=======================================");
                reportContent.AppendLine($"Ngày tạo báo cáo: {DateTime.Now.ToString("dd/MM/yyyy HH:mm")}");
                reportContent.AppendLine("---");
                reportContent.AppendLine($"Tổng số đơn hàng đã thanh toán: {totalOrders}");
                reportContent.AppendLine($"Tổng doanh thu: {totalRevenue.ToString("N0")} VNĐ");
                reportContent.AppendLine("---");
                reportContent.AppendLine();
                reportContent.AppendLine("CHI TIẾT CÁC ĐƠN HÀNG ĐÃ THANH TOÁN:");
                reportContent.AppendLine("---------------------------------------");

                // Định dạng header cho bảng
                reportContent.AppendLine(string.Format("{0,-11} | {1,-10} | {2,-25} | {3,15}",
                                                      "ID Đơn hàng", "Ngày đặt", "Người đặt (Email)", "Tổng tiền (VNĐ)"));
                reportContent.AppendLine(new string('-', 66)); // Dòng kẻ ngang

                foreach (var order in paidOrders.OrderByDescending(o => o.OrderDate))
                {
                    string email = order.User?.Email ?? "N/A";
                    string orderDate = order.OrderDate.ToString("dd/MM/yyyy");
                    string amount = order.TotalAmount.ToString("N0");

                    reportContent.AppendLine(string.Format("{0,-11} | {1,-10} | {2,-25} | {3,15}",
                                                      order.OrderID, orderDate, email, amount));
                }

                // 3. Chuẩn bị file để tải về
                string fileName = $"BaoCaoDoanhThu_{DateTime.Now.ToString("yyyyMMdd_HHmm")}.txt";
                byte[] fileBytes = Encoding.UTF8.GetBytes(reportContent.ToString());

                // Trả về file text
                return File(fileBytes, "text/plain", fileName);
            }
            catch (Exception) // Bỏ 'ex'
            {
                TempData["ErrorMessage"] = "Không thể tạo báo cáo. Đã có lỗi xảy ra.";
                return RedirectToPage(new { ActiveTab = "reports" });
            }
        }
        public async Task<IActionResult> OnPostDeleteFlightAsync(int flightId)
        {
            if (flightId <= 0)
            {
                TempData["ErrorMessage"] = "ID chuyến bay không hợp lệ.";
                return RedirectToPage(new { ActiveTab = "flights" });
            }
            var flight = await _context.FlightLists.FindAsync(flightId);
            if (flight == null)
            {
                TempData["ErrorMessage"] = "Không tìm thấy chuyến bay.";
                return RedirectToPage(new { ActiveTab = "flights" });
            }
            bool hasTickets = await _context.Tickets.AnyAsync(t => t.FlightID == flightId || t.ReturnFlightID == flightId);
            if (hasTickets)
            {
                TempData["ErrorMessage"] = $"Không thể xóa chuyến bay {flight.FlightNumber} vì đã có vé được đặt.";
                return RedirectToPage(new { ActiveTab = "flights" });
            }

            try
            {
                _context.FlightLists.Remove(flight);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = $"Đã xóa chuyến bay {flight.FlightNumber}.";
            }
            catch (Exception) 
            {
                TempData["ErrorMessage"] = "Đã xảy ra lỗi không mong muốn khi xóa chuyến bay.";
            }

            return RedirectToPage(new { ActiveTab = "flights" });
        }
        // --- Các hàm helper (ĐÃ SỬA LỖI) ---
        private string GetActivityType(string? notificationType)
        {
            if (string.IsNullOrEmpty(notificationType)) return "new";
            var lowerType = notificationType.ToLower();
            if (lowerType.Contains("cancel") || lowerType.Contains("fail") || lowerType.Contains("hủy")) return "error";
            if (lowerType.Contains("success") || lowerType.Contains("paid") || lowerType.Contains("complete") || lowerType.Contains("thành công")) return "success";
            return "new";
        }

        private string GetTimeAgo(DateTime dateTime)
        {
            var localTime = dateTime.ToLocalTime();
            // 🚀 SỬA LỖI: Khai báo timeSpan 🚀
            TimeSpan timeSpan = DateTime.Now - localTime;
            if (timeSpan.TotalSeconds < 1) return "vừa xong";
            if (timeSpan.TotalSeconds < 60) return $"{(int)timeSpan.TotalSeconds} giây trước";
            if (timeSpan.TotalMinutes < 60) return $"{(int)timeSpan.TotalMinutes} phút trước";
            if (timeSpan.TotalHours < 24) return $"{(int)timeSpan.TotalHours} giờ trước";
            return $"{(int)timeSpan.TotalDays} ngày trước";
        }

        private double? CalculatePercentageChange(double currentValue, double previousValue)
        {
            if (double.IsNaN(previousValue) || double.IsInfinity(previousValue)) { return null; }
            if (previousValue == 0) { return (currentValue > 0) ? 100.0 : ((currentValue == 0) ? 0.0 : (double?)null); }
            double change = ((currentValue - previousValue) / previousValue) * 100.0;
            return double.IsNaN(change) || double.IsInfinity(change) ? (double?)null : change;
        }

        private double? CalculatePercentageChange(int currentValue, int previousValue)
        {
            return CalculatePercentageChange((double)currentValue, (double)previousValue);
        }


    }

    // Class ActivityItem
    public class ActivityItem
    {
        public string Type { get; set; } = string.Empty;
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string TimeAgo { get; set; } = string.Empty;
    }
}