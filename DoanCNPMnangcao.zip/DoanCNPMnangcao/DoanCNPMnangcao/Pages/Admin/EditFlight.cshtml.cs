﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DoanCNPMnangcao.Data;
using DoanCNPMnangcao.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace DoanCNPMnangcao.Pages.Admin
{
    [Authorize(Roles = "Admin")]
    public class EditFlightModel : PageModel
    {
        private readonly FlightReservationDbContext _context;

        // Danh sách sân bay chuẩn (Copy từ AddFlight)
        private readonly Dictionary<string, string> _airportMappings = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { "SGN", "Sân bay Quốc tế Tân Sơn Nhất" },
            { "HAN", "Sân bay Quốc tế Nội Bài" },
            { "VCA", "Cảng hàng không quốc tế Cần Thơ" },
            { "DAD", "Sân bay Quốc tế Đà Nẵng" }
        };

        public EditFlightModel(FlightReservationDbContext context)
        {
            _context = context;
        }

        [BindProperty(SupportsGet = true)]
        public int Id { get; set; } // Nhận ID từ URL

        [BindProperty]
        public FlightInputModel Flight { get; set; } = new FlightInputModel();

        public List<SelectListItem> AirportOptions { get; set; } = new List<SelectListItem>();

        public async Task<IActionResult> OnGetAsync()
        {
            var flight = await _context.FlightLists.FindAsync(Id);
            if (flight == null)
            {
                TempData["ErrorMessage"] = "Không tìm thấy chuyến bay.";
                return RedirectToPage("/Admin/AdminDashboard", new { ActiveTab = "flights" });
            }

            // Điền dữ liệu từ DB vào InputModel
            Flight.FlightNumber = flight.FlightNumber;
            Flight.DepartureCode = flight.DepartureCode;
            Flight.ArrivalCode = flight.ArrivalCode;
            Flight.DepartureTime = flight.DepartureTime;
            Flight.ArrivalTime = flight.ArrivalTime;
            Flight.AvailableSeats = flight.AvailableSeats;
            Flight.Price = flight.Price;

            PopulateAirportOptions(); // Tạo dropdown
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            // Validation (Giống AddFlight)
            if (Flight.DepartureCode == Flight.ArrivalCode)
            {
                ModelState.AddModelError("Flight.ArrivalCode", "Sân bay đến không được trùng với sân bay đi.");
            }
            if (Flight.ArrivalTime <= Flight.DepartureTime)
            {
                ModelState.AddModelError("Flight.ArrivalTime", "Giờ đến phải sau giờ khởi hành.");
            }

            // Kiểm tra trùng số hiệu chuyến bay (loại trừ chính nó)
            bool flightNumberExists = await _context.FlightLists
                                            .AnyAsync(f => f.FlightNumber == Flight.FlightNumber && f.FlightID != Id);
            if (flightNumberExists)
            {
                ModelState.AddModelError("Flight.FlightNumber", $"Số hiệu {Flight.FlightNumber} đã tồn tại ở chuyến bay khác.");
            }

            if (!ModelState.IsValid)
            {
                PopulateAirportOptions(); // Tạo lại dropdown
                return Page();
            }

            // Tìm chuyến bay gốc
            var flightToUpdate = await _context.FlightLists.FindAsync(Id);
            if (flightToUpdate == null)
            {
                TempData["ErrorMessage"] = "Không tìm thấy chuyến bay để cập nhật.";
                return RedirectToPage("/Admin/AdminDashboard", new { ActiveTab = "flights" });
            }

            // Cập nhật thông tin
            flightToUpdate.FlightNumber = Flight.FlightNumber;
            flightToUpdate.DepartureCode = Flight.DepartureCode!.ToUpper();
            flightToUpdate.ArrivalCode = Flight.ArrivalCode!.ToUpper();
            // Lấy tên sân bay mới
            flightToUpdate.DepartureAirport = _airportMappings.GetValueOrDefault(Flight.DepartureCode!, "N/A");
            flightToUpdate.ArrivalAirport = _airportMappings.GetValueOrDefault(Flight.ArrivalCode!, "N/A");
            flightToUpdate.DepartureTime = Flight.DepartureTime;
            flightToUpdate.ArrivalTime = Flight.ArrivalTime;
            flightToUpdate.AvailableSeats = Flight.AvailableSeats;
            flightToUpdate.Price = Flight.Price;
            flightToUpdate.UpdatedDate = DateTime.UtcNow;

            try
            {
                _context.FlightLists.Update(flightToUpdate);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                ModelState.AddModelError(string.Empty, "Lỗi xung đột. Vui lòng thử lại.");
                PopulateAirportOptions();
                return Page();
            }

            TempData["SuccessMessage"] = $"Đã cập nhật chuyến bay {flightToUpdate.FlightNumber}.";
            return RedirectToPage("/Admin/AdminDashboard", new { ActiveTab = "flights" });
        }

        // Hàm helper (Copy từ AddFlight)
        private void PopulateAirportOptions()
        {
            AirportOptions = new List<SelectListItem> { new SelectListItem { Value = "", Text = "-- Chọn sân bay --" } };
            foreach (var airport in _airportMappings)
            {
                string displayName = airport.Value.Split(new[] { "Sân bay", "Cảng hàng không" }, StringSplitOptions.RemoveEmptyEntries)
                                           .FirstOrDefault()?.Trim() ?? airport.Value;
                AirportOptions.Add(new SelectListItem
                {
                    Value = airport.Key,
                    Text = $"{displayName} ({airport.Key})"
                });
            }
        }
    }
}