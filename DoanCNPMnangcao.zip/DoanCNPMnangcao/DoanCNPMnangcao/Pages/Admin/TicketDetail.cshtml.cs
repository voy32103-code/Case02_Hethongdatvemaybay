﻿using System;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using DoanCNPMnangcao.Data;
using DoanCNPMnangcao.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace DoanCNPMnangcao.Pages.Admin // 👈 Namespace Admin
{
    [Authorize(Roles = "Admin")] // Chỉ Admin mới vào được
    public class TicketDetailModel : PageModel
    {
        private readonly FlightReservationDbContext _context;

        public TicketDetailModel(FlightReservationDbContext context)
        {
            _context = context;
        }

        [BindProperty(SupportsGet = true)]
        public int TicketId { get; set; }

        public Ticket? Ticket { get; set; }
        public Order? Order { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            if (TicketId <= 0)
            {
                return RedirectToPage("/Admin/AdminDashboard", new { ActiveTab = "tickets" });
            }

            // 🚀 SỬA LOGIC: ADMIN CÓ THỂ XEM MỌI VÉ 🚀
            // Bỏ điều kiện "&& t.UserID == currentUserId"
            Ticket = await _context.Tickets
                .Include(t => t.Flight) // Thông tin chuyến bay
                .Include(t => t.ReturnFlight)
                .Include(t => t.User) // Thông tin người đặt
                .FirstOrDefaultAsync(t => t.TicketID == TicketId);

            if (Ticket == null)
            {
                TempData["ErrorMessage"] = "Không tìm thấy vé.";
                return RedirectToPage("/Admin/AdminDashboard", new { ActiveTab = "tickets" });
            }

            // Lấy thông tin Order (Đơn hàng)
            // (Giả sử liên kết 1-1 qua OrderDetail)
            var orderDetail = await _context.OrderDetails
                                .FirstOrDefaultAsync(od => od.TicketID == Ticket.TicketID);

            if (orderDetail != null)
            {
                Order = await _context.Orders.FindAsync(orderDetail.OrderID);
            }

            return Page();
        }
    }
}