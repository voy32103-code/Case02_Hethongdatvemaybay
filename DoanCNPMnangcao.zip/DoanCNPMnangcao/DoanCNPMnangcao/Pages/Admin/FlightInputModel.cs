﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DoanCNPMnangcao.Pages.Admin
{
    // Model này dùng chung cho cả AddFlight và EditFlight
    public class FlightInputModel
    {
        [Required(ErrorMessage = "Số hiệu chuyến bay là bắt buộc.")]
        [StringLength(20)]
        public string FlightNumber { get; set; } = string.Empty;

        [Required(ErrorMessage = "Mã sân bay khởi hành là bắt buộc.")]
        [StringLength(10)]
        public string? DepartureCode { get; set; }

        [Required(ErrorMessage = "Mã sân bay đến là bắt buộc.")]
        [StringLength(10)]
        public string? ArrivalCode { get; set; }

        [Required(ErrorMessage = "Ngày giờ khởi hành là bắt buộc.")]
        [DataType(DataType.DateTime)]
        public DateTime DepartureTime { get; set; } = DateTime.Now.AddDays(1);

        [Required(ErrorMessage = "Ngày giờ đến là bắt buộc.")]
        [DataType(DataType.DateTime)]
        public DateTime ArrivalTime { get; set; } = DateTime.Now.AddDays(1).AddHours(2);

        [Required(ErrorMessage = "Số ghế là bắt buộc.")]
        [Range(0, 1000, ErrorMessage = "Số ghế phải từ 0 đến 1000.")]
        public int AvailableSeats { get; set; }

        [Required(ErrorMessage = "Giá vé là bắt buộc.")]
        [Range(0.01, (double)decimal.MaxValue, ErrorMessage = "Giá vé phải là số dương.")]
        [DataType(DataType.Currency)]
        [Column(TypeName = "decimal(18, 2)")]
        public decimal Price { get; set; }
    }
}