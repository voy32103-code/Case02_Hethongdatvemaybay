﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using DoanCNPMnangcao.Data;
using DoanCNPMnangcao.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace DoanCNPMnangcao.Pages.Admin // 👈 Đảm bảo namespace này đúng
{
    [Authorize(Roles = "Admin")]
    public class EditUserModel : PageModel
    {
        private readonly FlightReservationDbContext _context;

        public EditUserModel(FlightReservationDbContext context)
        {
            _context = context;
        }

        // 🚀 THUỘC TÍNH "Id" (ĐANG BỊ THIẾU) 🚀
        [BindProperty(SupportsGet = true)]
        public int Id { get; set; } // Nhận ID từ URL (ví dụ: /EditUser/1)

        // 🚀 THUỘC TÍNH "Input" (ĐANG BỊ THIẾU) 🚀
        [BindProperty]
        public InputModel Input { get; set; } = new InputModel();

        // Model lồng để chứa dữ liệu form
        public class InputModel
        {
            [Required(ErrorMessage = "Tên đăng nhập là bắt buộc.")]
            public string Username { get; set; } = string.Empty;
            [Required(ErrorMessage = "Họ tên là bắt buộc.")]
            public string FullName { get; set; } = string.Empty;
            [Required(ErrorMessage = "Email là bắt buộc.")]
            [EmailAddress]
            public string Email { get; set; } = string.Empty;
            [Required(ErrorMessage = "Vai trò là bắt buộc.")]
            public string UserRole { get; set; } = "User";
            // Không bind mật khẩu khi edit
        }

        // Hàm OnGet: Tải thông tin user lên form
        public async Task<IActionResult> OnGetAsync()
        {
            var user = await _context.Users.FindAsync(Id);
            if (user == null)
            {
                TempData["ErrorMessage"] = "Không tìm thấy người dùng.";
                return RedirectToPage("/Admin/AdminDashboard", new { ActiveTab = "users" });
            }

            // Điền dữ liệu từ DB vào InputModel
            Input.Username = user.Username;
            Input.FullName = user.FullName;
            Input.Email = user.Email;
            Input.UserRole = user.UserRole;

            return Page();
        }

        // Hàm OnPost: Lưu thay đổi
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page(); // Trả về trang nếu có lỗi validation
            }

            var userToUpdate = await _context.Users.FindAsync(Id);
            if (userToUpdate == null)
            {
                TempData["ErrorMessage"] = "Không tìm thấy người dùng để cập nhật.";
                return RedirectToPage("/Admin/AdminDashboard", new { ActiveTab = "users" });
            }

            // Kiểm tra email/username mới có bị trùng không (loại trừ chính nó)
            var existingUser = await _context.Users.AnyAsync(u => (u.Username == Input.Username || u.Email == Input.Email) && u.UserID != Id);
            if (existingUser)
            {
                ModelState.AddModelError(string.Empty, "Tên đăng nhập hoặc Email đã tồn tại ở tài khoản khác.");
                return Page();
            }

            // Cập nhật thông tin từ InputModel
            userToUpdate.Username = Input.Username;
            userToUpdate.FullName = Input.FullName;
            userToUpdate.Email = Input.Email;
            userToUpdate.UserRole = Input.UserRole;
            userToUpdate.UpdatedDate = DateTime.UtcNow;

            try
            {
                _context.Users.Update(userToUpdate);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException) // 🚀 Sửa lỗi 'ex' không dùng
            {
                ModelState.AddModelError(string.Empty, "Lỗi xung đột. Vui lòng thử lại.");
                return Page();
            }
            catch (Exception) // 🚀 Sửa lỗi 'ex' không dùng
            {
                ModelState.AddModelError(string.Empty, "Đã xảy ra lỗi khi lưu.");
                return Page();
            }

            TempData["SuccessMessage"] = $"Đã cập nhật người dùng {userToUpdate.Username}.";
            return RedirectToPage("/Admin/AdminDashboard", new { ActiveTab = "users" });
        }
    }
}