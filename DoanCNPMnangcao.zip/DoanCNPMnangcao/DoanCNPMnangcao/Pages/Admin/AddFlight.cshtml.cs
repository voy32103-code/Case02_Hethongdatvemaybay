﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering; // <-- Thêm using cho SelectListItem
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Threading.Tasks;
using DoanCNPMnangcao.Data;
using DoanCNPMnangcao.Models;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Collections.Generic;
using System;
using Microsoft.AspNetCore.Authorization; // Thêm

namespace DoanCNPMnangcao.Pages.Admin // Đảm bảo namespace đúng
{
    [Authorize(Roles = "Admin")]
    public class AddFlightModel : PageModel
    {
        private readonly FlightReservationDbContext _context;

        // Danh sách sân bay chuẩn
        private readonly Dictionary<string, string> _airportMappings = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { "SGN", "Sân bay Quốc tế Tân Sơn Nhất" },
            { "HAN", "Sân bay Quốc tế Nội Bài" },
            { "VCA", "Cảng hàng không quốc tế Cần Thơ" },
            { "DAD", "Sân bay Quốc tế Đà Nẵng" }
        };

        public AddFlightModel(FlightReservationDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public FlightInputModel NewFlight { get; set; } = new FlightInputModel();

        public List<SelectListItem> AirportOptions { get; set; } = new List<SelectListItem>();

        public async Task OnGetAsync()
        {
            // --- 🚀 SỬA LỖI 1: Code tìm maxNum 🚀 ---
            var lastFlightNumberStr = await _context.FlightLists
                .Where(f => f.FlightNumber.StartsWith("FL"))
                .Select(f => f.FlightNumber.Substring(2))
                .ToListAsync();

            int nextFlightNum = 1001;

            if (lastFlightNumberStr.Any())
            {
                int maxNum = 0;
                foreach (var numStr in lastFlightNumberStr)
                {
                    if (int.TryParse(numStr, out int currentNum))
                    {
                        if (currentNum > maxNum) maxNum = currentNum;
                    }
                }
                if (maxNum > 0) nextFlightNum = maxNum + 1;
            }
            NewFlight.FlightNumber = $"FL{nextFlightNum}";
            // --- (Kết thúc sửa lỗi 1) ---

            PopulateAirportOptions(); // Tạo dropdown
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (NewFlight.DepartureCode == NewFlight.ArrivalCode)
            {
                ModelState.AddModelError("NewFlight.ArrivalCode", "Sân bay đến không được trùng với sân bay đi.");
            }
            if (NewFlight.ArrivalTime <= NewFlight.DepartureTime)
            {
                ModelState.AddModelError("NewFlight.ArrivalTime", "Giờ đến phải sau giờ khởi hành.");
            }

            // --- 🚀 SỬA LỖI 2: Xử lý trùng 🚀 ---
            bool flightNumberExists = await _context.FlightLists.AnyAsync(f => f.FlightNumber == NewFlight.FlightNumber);
            if (flightNumberExists)
            {
                ModelState.AddModelError("NewFlight.FlightNumber", $"Số hiệu {NewFlight.FlightNumber} đã tồn tại. Số mới đã được đề xuất.");
            }
            // --- (Kết thúc sửa lỗi 2) ---

            string departureAirportName = _airportMappings.GetValueOrDefault(NewFlight.DepartureCode ?? "", "Không xác định");
            string arrivalAirportName = _airportMappings.GetValueOrDefault(NewFlight.ArrivalCode ?? "", "Không xác định");

            if (departureAirportName == "Không xác định" && !string.IsNullOrEmpty(NewFlight.DepartureCode))
            {
                ModelState.AddModelError("NewFlight.DepartureCode", "Mã sân bay đi không hợp lệ.");
            }
            if (arrivalAirportName == "Không xác định" && !string.IsNullOrEmpty(NewFlight.ArrivalCode))
            {
                ModelState.AddModelError("NewFlight.ArrivalCode", "Mã sân bay đến không hợp lệ.");
            }

            if (!ModelState.IsValid)
            {
                PopulateAirportOptions(); // Tạo lại dropdown nếu lỗi
                return Page();
            }

            // Nếu trùng số hiệu (đã báo lỗi), gọi lại OnGet để lấy số mới
            if (flightNumberExists)
            {
                await OnGetAsync(); // Tải lại số FL mới nhất
                return Page();
            }

            var flightToAdd = new FlightList
            {
                FlightNumber = NewFlight.FlightNumber,
                DepartureAirport = departureAirportName,
                DepartureCode = NewFlight.DepartureCode!.ToUpper(),
                ArrivalAirport = arrivalAirportName,
                ArrivalCode = NewFlight.ArrivalCode!.ToUpper(),
                DepartureTime = NewFlight.DepartureTime,
                ArrivalTime = NewFlight.ArrivalTime,
                AvailableSeats = NewFlight.AvailableSeats,
                Price = NewFlight.Price,
            };

            _context.FlightLists.Add(flightToAdd);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = $"Đã thêm thành công chuyến bay {flightToAdd.FlightNumber}!";
            return RedirectToPage("/Admin/AdminDashboard", new { ActiveTab = "flights" });
        }

        // Hàm helper tạo dropdown
        private void PopulateAirportOptions()
        {
            AirportOptions = new List<SelectListItem> { new SelectListItem { Value = "", Text = "-- Chọn sân bay --" } };
            foreach (var airport in _airportMappings)
            {
                string displayName = airport.Value.Split(new[] { "Sân bay", "Cảng hàng không" }, StringSplitOptions.RemoveEmptyEntries)
                                           .FirstOrDefault()?.Trim() ?? airport.Value;
                AirportOptions.Add(new SelectListItem
                {
                    Value = airport.Key,
                    Text = $"{displayName} ({airport.Key})"
                });
            }
        }
    }

   
}