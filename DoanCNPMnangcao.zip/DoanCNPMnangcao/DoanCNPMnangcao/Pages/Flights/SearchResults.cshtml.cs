﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DoanCNPMnangcao.Data; // <<< Namespace DbContext
using DoanCNPMnangcao.Models; // <<< Namespace Models
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace FlightReservationRazor.Pages.Flights
{
    public class SearchResultsModel : PageModel
    {
        private readonly FlightReservationDbContext _context;

        public SearchResultsModel(FlightReservationDbContext context)
        {
            _context = context;
        }

        // Danh sách chuyến bay tìm được để hiển thị
        public List<FlightList> Flights { get; set; } = new List<FlightList>();

        // Thuộc tính để nhận các tham số tìm kiếm từ URL (từ trang Index)
        [BindProperty(SupportsGet = true)]
        public string? FlightIds { get; set; } // Chuỗi ID (vd: "1,5,10")

        [BindProperty(SupportsGet = true)]
        public string? Departure { get; set; } // Mã sân bay đi

        [BindProperty(SupportsGet = true)]
        public string? Destination { get; set; } // Mã sân bay đến

        [BindProperty(SupportsGet = true)]
        public string? DepartureDate { get; set; } // Ngày đi (dạng chuỗi yyyy-MM-dd)

        [BindProperty(SupportsGet = true)]
        public int Adults { get; set; } = 1;

        [BindProperty(SupportsGet = true)]
        public int Children { get; set; } = 0;

        // Thuộc tính bổ sung để hiển thị tóm tắt
        public string? DepartureAirportName { get; set; }
        public string? ArrivalAirportName { get; set; }
        public DateTime? ParsedDepartureDate { get; set; }


        public async Task<IActionResult> OnGetAsync()
        {
            // Kiểm tra xem có nhận được danh sách ID không
            if (string.IsNullOrEmpty(FlightIds))
            {
                TempData["ErrorMessage"] = "Không có thông tin tìm kiếm để hiển thị kết quả.";
                return RedirectToPage("/Index"); // Quay về trang tìm kiếm
            }

            // Xử lý chuỗi ID thành List<int>
            List<int> idList = new List<int>();
            try
            {
                idList = FlightIds.Split(',')
                                  .Select(idStr => int.Parse(idStr.Trim())) // Chuyển chuỗi thành int
                                  .ToList();
            }
            catch
            {
                TempData["ErrorMessage"] = "Thông tin tìm kiếm không hợp lệ.";
                return RedirectToPage("/Index");
            }

            if (!idList.Any())
            {
                TempData["ErrorMessage"] = "Không có chuyến bay nào được tìm thấy.";
                return RedirectToPage("/Index");
            }

            // Truy vấn database để lấy thông tin chi tiết các chuyến bay theo ID
            try
            {
                Flights = await _context.FlightLists
                                .Where(f => idList.Contains(f.FlightID)) // Lọc theo danh sách ID
                                .OrderBy(f => f.DepartureTime) // Sắp xếp lại theo giờ bay
                                .ToListAsync();

                // Lấy thêm thông tin để hiển thị tóm tắt (tên sân bay, parse ngày)
                if (Flights.Any())
                {
                    DepartureAirportName = Flights.First().DepartureAirport; // Lấy từ kết quả đầu tiên
                    ArrivalAirportName = Flights.First().ArrivalAirport;
                }
                else // Lấy từ Db nếu list rỗng (ít xảy ra)
                {
                    DepartureAirportName = await _context.FlightLists.Where(f => f.DepartureCode == Departure).Select(f => f.DepartureAirport).FirstOrDefaultAsync() ?? Departure;
                    ArrivalAirportName = await _context.FlightLists.Where(f => f.ArrivalCode == Destination).Select(f => f.ArrivalAirport).FirstOrDefaultAsync() ?? Destination;
                }

                if (DateTime.TryParse(DepartureDate, out DateTime parsedDate))
                {
                    ParsedDepartureDate = parsedDate;
                }

            }
            catch (Exception )
            {
                // Ghi log lỗi ex
                TempData["ErrorMessage"] = "Đã xảy ra lỗi khi tải danh sách chuyến bay.";
                return RedirectToPage("/Index");
            }

            return Page(); // Hiển thị trang SearchResults với danh sách Flights
        }
    }
}