﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using DoanCNPMnangcao.Data;
using DoanCNPMnangcao.Models;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using DoanCNPMnangcao.Services;

namespace FlightReservationRazor.Pages.Flights
{
    [Authorize]
    public class BookingModel : PageModel
    {
        private readonly FlightReservationDbContext _context;
        private readonly IVnPayService _vnPayService;

        public BookingModel(FlightReservationDbContext context, IVnPayService vnPayService)
        {
            _context = context;
            _vnPayService = vnPayService;
        }

        public FlightList? SelectedFlight { get; set; }

        [BindProperty(SupportsGet = true)]
        public int FlightId { get; set; }
        [BindProperty(SupportsGet = true)]
        [Range(1, 10)]
        public int Adults { get; set; } = 1;
        [BindProperty(SupportsGet = true)]
        [Range(0, 10)]
        public int Children { get; set; } = 0;

        [BindProperty(SupportsGet = true)]
        public string SeatClass { get; set; } = "Phổ thông";
        [BindProperty(SupportsGet = true)]
        public string TripType { get; set; } = "OneWay";

        [BindProperty]
        public bool AddLuggage { get; set; } = false;
        [BindProperty]
        public bool AddMeal { get; set; } = false;

        [BindProperty]
        public List<PassengerInputModel> Passengers { get; set; } = new List<PassengerInputModel>();

        [BindProperty]
        [Required]
        public string BankCode { get; set; } = "Default";
        [BindProperty]
        [Required]
        public string Locale { get; set; } = "vn";

        // 🚀 BƯỚC 1: THÊM 2 THUỘC TÍNH NÀY (ĐỂ SỬA LỖI) 🚀
        [BindProperty]
        [Required(ErrorMessage = "Vui lòng chọn ghế.")]
        public string SelectedSeats { get; set; } = string.Empty; // Lưu dạng "14A,14B"

        public List<string> BookedSeats { get; set; } = new List<string>(); // Danh sách ghế đã bị đặt

        // --- Thuộc tính hiển thị giá ---
        public decimal TotalCalculatedPrice { get; set; }
        public decimal BaseAdultPrice { get; set; }

        public class PassengerInputModel
        {
            [Required(ErrorMessage = "Vui lòng nhập họ tên.")]
            public string FullName { get; set; } = string.Empty;
            [Required(ErrorMessage = "Vui lòng nhập email.")]
            [EmailAddress]
            public string Email { get; set; } = string.Empty;
            [Required(ErrorMessage = "Vui lòng nhập SĐT.")]
            public string Phone { get; set; } = string.Empty;
        }

        // --- Hàm Tính Giá (Giữ nguyên) ---
        private decimal CalculateTotalPrice(FlightList flight)
        {
            decimal multiplier = GetSeatClassMultiplier(SeatClass);
            decimal baseAdultPrice = flight.Price * multiplier;
            decimal childPrice = baseAdultPrice * 0.75m;
            decimal finalTotalPrice = (baseAdultPrice * Adults) + (childPrice * Children);
            if (TripType == "RoundTrip") finalTotalPrice *= 2;
            int totalPassengers = Adults + Children;
            if (AddLuggage) finalTotalPrice += (300000 * totalPassengers);
            if (AddMeal) finalTotalPrice += (150000 * totalPassengers);
            return finalTotalPrice;
        }
        private decimal GetSeatClassMultiplier(string seatClass)
        {
            switch (seatClass)
            {
                case "Phổ thông đặc biệt": return 1.4m;
                case "Thương gia": return 2.0m;
                case "Hạng nhất": return 2.8m;
                default: return 1.0m;
            }
        }

        // --- 🚀 BƯỚC 2: CẬP NHẬT OnGetAsync 🚀 ---
        public async Task<IActionResult> OnGetAsync()
        {
            if (FlightId <= 0) return RedirectToPage("/Index");
            SelectedFlight = await _context.FlightLists.FindAsync(FlightId);
            if (SelectedFlight == null) { TempData["ErrorMessage"] = "Không tìm thấy chuyến bay."; return RedirectToPage("/Index"); }

            int totalPassengers = Adults + Children;
            if (totalPassengers <= 0) totalPassengers = 1;

            if (SelectedFlight.AvailableSeats < totalPassengers)
            {
                TempData["ErrorMessage"] = $"Không đủ ghế trống cho {totalPassengers} hành khách.";
                return RedirectToPage("/Index");
            }

            // Tính toán giá để hiển thị
            decimal multiplier = GetSeatClassMultiplier(SeatClass);
            BaseAdultPrice = SelectedFlight.Price * multiplier;
            TotalCalculatedPrice = CalculateTotalPrice(SelectedFlight);

            // Khởi tạo List Passengers
            for (int i = 0; i < totalPassengers; i++)
            {
                Passengers.Add(new PassengerInputModel());
            }

            if (User.Identity != null && User.Identity.IsAuthenticated && Passengers.Count > 0)
            {
                Passengers[0].FullName = User.Claims.FirstOrDefault(c => c.Type == "FullName")?.Value ?? string.Empty;
                Passengers[0].Email = User.FindFirst(ClaimTypes.Email)?.Value ?? string.Empty;
            }

            // 🚀 LẤY DANH SÁCH GHẾ ĐÃ ĐẶT 🚀
            BookedSeats = await _context.Tickets
                .Where(t => t.FlightID == FlightId && (t.TicketStatus == "Booked" || t.TicketStatus == "Queued"))
                .Select(t => t.SeatNumber) // Lấy chuỗi SeatNumber (ví dụ: "14A,14B")
                .ToListAsync();

            // Chuyển đổi danh sách chuỗi (["14A,14B", "15C"]) thành danh sách các ghế riêng lẻ (["14A", "14B", "15C"])
            var individualSeats = new List<string>();
            foreach (var seatString in BookedSeats)
            {
                individualSeats.AddRange(seatString.Split(',').Where(s => !string.IsNullOrWhiteSpace(s)));
            }
            BookedSeats = individualSeats;

            return Page();
        }

        // --- 🚀 BƯỚC 3: CẬP NHẬT OnPostAsync 🚀 ---
        public async Task<IActionResult> OnPostAsync()
        {
            int totalPassengers = Adults + Children;
            if (totalPassengers <= 0) totalPassengers = 1;

            SelectedFlight = await _context.FlightLists.FindAsync(FlightId);

            // Validation
            if (SelectedFlight == null || SelectedFlight.AvailableSeats < totalPassengers || !ModelState.IsValid)
            {
                ModelState.AddModelError(string.Empty, "Thông tin không hợp lệ hoặc chuyến bay đã hết vé.");
                await OnGetAsync(); // Tải lại giá và form
                return Page();
            }

            // 🚀 Kiểm tra số lượng ghế đã chọn
            int selectedSeatCount = SelectedSeats.Split(',').Count(s => !string.IsNullOrWhiteSpace(s));
            if (selectedSeatCount != totalPassengers)
            {
                ModelState.AddModelError("SelectedSeats", $"Bạn phải chọn đúng {totalPassengers} ghế.");
                await OnGetAsync(); // Tải lại
                return Page();
            }

            var userIdString = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (!int.TryParse(userIdString, out int userId))
            {
                ModelState.AddModelError(string.Empty, "Không thể xác thực người dùng.");
                await OnGetAsync(); // Tải lại
                return Page();
            }

            decimal finalTotalPrice = CalculateTotalPrice(SelectedFlight);

            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                var newTicket = new Ticket
                {
                    FlightID = SelectedFlight.FlightID,
                    UserID = userId,
                    BookingDate = DateTime.UtcNow,
                    SeatNumber = SelectedSeats, // 👈 SỬ DỤNG GHẾ NGƯỜI DÙNG CHỌN
                    TicketType = SeatClass,
                    TicketPrice = finalTotalPrice,
                    TicketStatus = "Queued",
                };
                _context.Tickets.Add(newTicket);
                await _context.SaveChangesAsync();

                var primaryPassenger = Passengers.First();

                var newOrder = new Order
                {
                    UserID = userId,
                    OrderDate = DateTime.UtcNow.Date,
                    TotalAmount = finalTotalPrice,
                    PaymentStatus = "Pending",
                    AddressDelivery = $"Vé điện tử - {primaryPassenger.Email}",
                    PaymentMethod = $"VNPAY-{BankCode}",
                    OrderStatus = "Pending",
                };
                _context.Orders.Add(newOrder);
                await _context.SaveChangesAsync();

                var newOrderDetail = new OrderDetail
                {
                    OrderID = newOrder.OrderID,
                    TicketID = newTicket.TicketID,
                    Quantity = totalPassengers,
                    UnitPrice = (SelectedFlight.Price * GetSeatClassMultiplier(SeatClass)),
                };
                _context.OrderDetails.Add(newOrderDetail);

                SelectedFlight.AvailableSeats -= totalPassengers;
                _context.FlightLists.Update(SelectedFlight);

                await _context.SaveChangesAsync();
                await transaction.CommitAsync();

                // --- TẠO VNPAY URL VÀ CHUYỂN HƯỚNG ---
                var paymentInfo = new PaymentInformationModel
                {
                    OrderId = newOrder.OrderID,
                    Amount = (double)newOrder.TotalAmount,
                    OrderDescription = $"Dat ve #{newOrder.OrderID} cho {primaryPassenger.FullName}",
                    Name = primaryPassenger.FullName
                };

                string paymentUrl = _vnPayService.CreatePaymentUrl(paymentInfo, HttpContext, BankCode, Locale);

                return Redirect(paymentUrl);
            }
            catch (DbUpdateConcurrencyException)
            {
                await transaction.RollbackAsync();
                ModelState.AddModelError(string.Empty, "Lỗi: Ghế vừa bị người khác đặt. Vui lòng thử lại.");
            }
            catch (Exception)
            {
                await transaction.RollbackAsync();
                ModelState.AddModelError(string.Empty, "Lỗi hệ thống, không thể đặt vé.");
            }

            // Nếu lỗi, tải lại thông tin
            SelectedFlight = await _context.FlightLists.FindAsync(FlightId);
            await OnGetAsync();
            return Page();
        }

        // 🚀 ĐÃ XÓA HÀM GenerateSeatNumber() (vì đã dùng ghế người dùng chọn) 🚀
    }
}