﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using System.Security.Claims; // 👈 Thêm using này
using DoanCNPMnangcao.Models; // 👈 Thêm using này
using DoanCNPMnangcao.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace FlightReservationRazor.Pages // 👈 Namespace Gốc
{
    public class IndexModel : PageModel
    {
        private readonly FlightReservationDbContext _context;

        public IndexModel(FlightReservationDbContext context)
        {
            _context = context;
        }

        // --- Thuộc tính Form ---
        [BindProperty(SupportsGet = true)]
        [Required(ErrorMessage = "Vui lòng chọn điểm đi.")]
        public string? Departure { get; set; }

        [BindProperty(SupportsGet = true)]
        [Required(ErrorMessage = "Vui lòng chọn điểm đến.")]
        public string? Destination { get; set; }

        [BindProperty(SupportsGet = true)]
        [DataType(DataType.Date)]
        [Required(ErrorMessage = "Vui lòng chọn ngày đi.")]
        public DateTime? DepartureDate { get; set; }

        [BindProperty(SupportsGet = true)]
        [DataType(DataType.Date)]
        public DateTime? ReturnDate { get; set; }

        [BindProperty(SupportsGet = true)]
        public string SeatClass { get; set; } = "Phổ thông";

        [BindProperty(SupportsGet = true)]
        public string TripType { get; set; } = "OneWay";
        [BindProperty]
        public string? FeedbackMessage { get; set; }
        [BindProperty]
        public int FeedbackRating { get; set; } = 5; // Mặc định 5 sao
        [BindProperty(SupportsGet = true)]
        [Range(1, 10, ErrorMessage = "Ít nhất 1 người lớn.")]
        public int Adults { get; set; } = 1;

        [BindProperty(SupportsGet = true)]
        [Range(0, 10, ErrorMessage = "Số trẻ em không hợp lệ.")]

        public int Children { get; set; } = 0;

        // --- Thuộc tính Hiển thị ---
        public string? SearchMessage { get; set; }
        public List<FlightList> SearchResults { get; set; } = new List<FlightList>();
        public bool SearchPerformed { get; set; } = false;

        // 🚀 HÀM HELPER 1: Tính giá theo Hạng Vé
        private decimal GetSeatClassMultiplier(string seatClass)
        {
            switch (seatClass)
            {
                case "Phổ thông đặc biệt": return 1.4m; // 140%
                case "Thương gia": return 2.0m; // 200%
                case "Hạng nhất": return 2.8m; // 280%
                default: return 1.0m; // 100% (Phổ thông)
            }
        }
        public async Task<IActionResult> OnPostSubmitFeedbackAsync()
        {
            // 1. Kiểm tra xem user đã đăng nhập chưa
            var userIdString = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userIdString) || !int.TryParse(userIdString, out int userId))
            {
                // Nếu chưa đăng nhập, không cho gửi
                TempData["ErrorMessage"] = "Bạn cần đăng nhập để gửi đánh giá.";
                return RedirectToPage("/Index", null, "feedback-form"); // Chuyển về trang chủ, nhảy đến form
            }

            // 2. Kiểm tra nội dung
            if (string.IsNullOrWhiteSpace(FeedbackMessage) || FeedbackRating < 1 || FeedbackRating > 5)
            {
                TempData["ErrorMessage"] = "Nội dung đánh giá không hợp lệ.";
                return RedirectToPage("/Index", null, "feedback-form");
            }

            // 3. Tạo Feedback mới
            var feedback = new Feedback
            {
                UserID = userId,
                Message = FeedbackMessage,
                Rating = FeedbackRating,
                CreatedDate = DateTime.UtcNow
            };

            _context.Feedbacks.Add(feedback);

            // (Tùy chọn: Thêm Notification cho Admin)
            var notification = new Notification
            {
                UserID = 1, // ID Admin (hoặc UserID của người gửi)
                Message = $"Người dùng (ID: {userId}) đã gửi đánh giá {FeedbackRating} sao.",
                NotificationType = "NewFeedback",
                IsRead = false
            };
            _context.Notifications.Add(notification);

            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Cảm ơn bạn đã gửi đánh giá!";
            return RedirectToPage("/Index", null, "feedback-form");
        }
        public void OnGet()
        {
            if (!DepartureDate.HasValue)
            {
                DepartureDate = DateTime.Today;
            }
        }

        public async Task<IActionResult> OnPostAsync()
        {
            SearchPerformed = true;

            if (!ModelState.IsValid)
            {
                SearchMessage = "Vui lòng kiểm tra lại thông tin bạn đã nhập.";
                return Page();
            }
            if (Departure == Destination)
            {
                ModelState.AddModelError(nameof(Destination), "Điểm đi và Điểm đến không được trùng nhau.");
                SearchMessage = "Điểm đi và Điểm đến không được trùng nhau.";
                return Page();
            }
            if (TripType == "RoundTrip")
            {
                if (!ReturnDate.HasValue)
                {
                    ModelState.AddModelError(nameof(ReturnDate), "Vui lòng chọn Ngày về cho chuyến khứ hồi.");
                    SearchMessage = "Vui lòng chọn Ngày về cho chuyến khứ hồi.";
                    return Page();
                }
                if (ReturnDate.Value.Date < DepartureDate!.Value.Date)
                {
                    ModelState.AddModelError(nameof(ReturnDate), "Ngày về phải sau hoặc trùng với Ngày đi.");
                    SearchMessage = "Ngày về phải sau hoặc trùng với Ngày đi.";
                    return Page();
                }
            }

            try
            {
                var query = _context.FlightLists.AsQueryable();
                query = query.Where(f => f.DepartureCode == Departure && f.ArrivalCode == Destination);

                // Sửa lỗi tìm kiếm ngày (TimeZone)
                if (DepartureDate.HasValue)
                {
                    var selectedDate = DepartureDate.Value.Date;
                    var nextDay = selectedDate.AddDays(1);
                    query = query.Where(f => f.DepartureTime >= selectedDate && f.DepartureTime < nextDay);
                }

                int totalPassengers = Adults + Children;
                if (totalPassengers <= 0) totalPassengers = 1;
                query = query.Where(f => f.AvailableSeats >= totalPassengers);

                query = query.OrderBy(f => f.DepartureTime);
                SearchResults = await query.ToListAsync();

                // 🚀 NÂNG CẤP: Cập nhật giá vé theo hạng vé đã chọn
                decimal multiplier = GetSeatClassMultiplier(SeatClass);
                if (multiplier != 1.0m)
                {
                    foreach (var flight in SearchResults)
                    {
                        flight.Price = flight.Price * multiplier;
                    }
                }

                if (!SearchResults.Any())
                {
                    var depAirport = await _context.FlightLists.Where(f => f.DepartureCode == Departure).Select(f => f.DepartureAirport).FirstOrDefaultAsync() ?? Departure;
                    var arrAirport = await _context.FlightLists.Where(f => f.ArrivalCode == Destination).Select(f => f.ArrivalAirport).FirstOrDefaultAsync() ?? Destination;
                    SearchMessage = $"Không tìm thấy chuyến bay nào từ <strong>{depAirport}</strong> đến <strong>{arrAirport}</strong> vào ngày <strong>{DepartureDate.Value.ToShortDateString()}</strong> phù hợp.";
                }
                else
                {
                    SearchMessage = null;
                }
            }
            catch (Exception)
            {
                SearchMessage = "Đã xảy ra lỗi hệ thống khi tìm kiếm. Vui lòng thử lại sau.";
                SearchResults = new List<FlightList>();
            }

            return Page();
        }
    }
}