﻿using System;
using System.Linq;
using System.Threading.Tasks;
using DoanCNPMnangcao.Data;
using DoanCNPMnangcao.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using DoanCNPMnangcao.Models; // Thêm

namespace FlightReservationRazor.Pages
{
    public class PaymentCallbackModel : PageModel
    {
        private readonly IVnPayService _vnPayService;
        private readonly FlightReservationDbContext _context;

        public PaymentCallbackModel(IVnPayService vnPayService, FlightReservationDbContext context)
        {
            _vnPayService = vnPayService;
            _context = context;
        }

        public string Message { get; set; } = string.Empty;
        public bool IsSuccess { get; set; } = false;

        public async Task<IActionResult> OnGetAsync()
        {
            // 1. Lấy phản hồi từ VNPAY
            var response = _vnPayService.PaymentExecute(Request.Query);

            if (response == null || !response.Success)
            {
                Message = "Thanh toán VNPAY thất bại: Chữ ký không hợp lệ.";
                IsSuccess = false;
                return Page();
            }

            if (!int.TryParse(response.OrderId, out int orderId))
            {
                Message = "Lỗi: Mã đơn hàng không hợp lệ.";
                IsSuccess = false;
                return Page();
            }

            if (response.VnPayResponseCode != "00")
            {
                Message = $"Thanh toán thất bại tại VNPAY. Mã lỗi: {response.VnPayResponseCode}";
                IsSuccess = false;
                return Page();
            }

            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                var order = await _context.Orders.FindAsync(orderId);
                if (order == null)
                {
                    Message = "Lỗi: Không tìm thấy đơn hàng trong hệ thống.";
                    IsSuccess = false;
                    return Page();
                }

                if (order.PaymentStatus == "Paid")
                {
                    Message = "Đơn hàng này đã được thanh toán thành công trước đó.";
                    IsSuccess = true;
                    return Page();
                }

                order.PaymentStatus = "Paid";
                order.OrderStatus = "Confirmed";

                var orderDetail = await _context.OrderDetails.FirstOrDefaultAsync(od => od.OrderID == orderId);
                if (orderDetail != null)
                {
                    var ticket = await _context.Tickets.FindAsync(orderDetail.TicketID);
                    if (ticket != null)
                    {
                        ticket.TicketStatus = "Booked";
                        _context.Tickets.Update(ticket);
                    }
                }

                _context.Orders.Update(order);
                await _context.SaveChangesAsync();
                await transaction.CommitAsync();

                Message = $"Thanh toán thành công cho đơn hàng #{order.OrderID}!";
                IsSuccess = true;
            }
            catch (Exception)
            {
                await transaction.RollbackAsync();
                Message = "Đã xảy ra lỗi khi cập nhật trạng thái đơn hàng.";
                IsSuccess = false;
            }

            return Page();
        }
    }
}