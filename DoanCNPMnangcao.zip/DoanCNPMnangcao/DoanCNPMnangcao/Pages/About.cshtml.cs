﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FlightReservationRazor.Pages
{
    public class AboutModel : PageModel
    {
        public void OnGet()
        {
            // Không cần logic backend phức tạp
        }
    }
}