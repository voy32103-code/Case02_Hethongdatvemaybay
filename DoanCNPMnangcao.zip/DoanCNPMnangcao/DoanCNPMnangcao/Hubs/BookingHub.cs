﻿using Microsoft.AspNetCore.SignalR;
using System.Threading.Tasks;

namespace DoanCNPMnangcao.Hubs // 👈 Đảm bảo namespace khớp với project
{
    public class BookingHub : Hub
    {
        // Khi một người dùng mở trang Booking, họ sẽ "tham gia" vào nhóm của chuyến bay đó
        public async Task JoinFlightGroup(string flightId)
        {
            await Groups.AddToGroupAsync(Context.ConnectionId, flightId);
        }

        // Khi một người dùng rời trang Booking
        public async Task LeaveFlightGroup(string flightId)
        {
            await Groups.RemoveFromGroupAsync(Context.ConnectionId, flightId);
        }

        // Khi User A chọn 1 ghế
        public async Task SelectSeat(string flightId, string seatId)
        {
            // Gửi thông báo đến TẤT CẢ user khác trong nhóm (trừ người gửi)
            await Clients.OthersInGroup(flightId).SendAsync("SeatTaken", seatId);
        }

        // Khi User A bỏ chọn 1 ghế
        public async Task UnselectSeat(string flightId, string seatId)
        {
            // Gửi thông báo đến TẤT CẢ user khác
            await Clients.OthersInGroup(flightId).SendAsync("SeatFreed", seatId);
        }
    }
}