﻿using Microsoft.AspNetCore.Http;

namespace DoanCNPMnangcao.Services // (Hoặc namespace của bạn)
{
    public interface IVnPayService
    {
        // 🚀 Sửa lại hàm này để nhận BankCode và Locale
        string CreatePaymentUrl(PaymentInformationModel model, HttpContext context, string bankCode, string locale);
        PaymentResponseModel PaymentExecute(IQueryCollection collections);
    }
}