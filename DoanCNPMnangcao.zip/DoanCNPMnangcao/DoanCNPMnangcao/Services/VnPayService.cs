﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System;
using System.Linq;

namespace DoanCNPMnangcao.Services // (Hoặc namespace của bạn)
{
    public class VnPayService : IVnPayService
    {
        private readonly IConfiguration _configuration;

        public VnPayService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        // 🚀 HÀM ĐÃ SỬA LỖI ĐẦY ĐỦ 🚀
        public string CreatePaymentUrl(PaymentInformationModel model, HttpContext context, string bankCode, string locale)
        {
            var timeZoneById = TimeZoneInfo.FindSystemTimeZoneById(_configuration["TimeZoneId"] ?? "SE Asia Standard Time");
            var timeNow = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, timeZoneById);
            
            // Dùng OrderId thật từ Model
            var vnp_TxnRef = model.OrderId.ToString(); 
            var pay = new VnPayLibrary();
            
            // 🚀 SỬA LỖI ĐỌC CONFIG 🚀
            // Đọc đúng đường dẫn key trong appsettings.json
            var urlCallBack = _configuration["Vnpay:PaymentBackReturnUrl"]; 

            pay.AddRequestData("vnp_Version", _configuration["Vnpay:Version"] ?? "2.1.0");
            pay.AddRequestData("vnp_Command", _configuration["Vnpay:Command"] ?? "pay");
            pay.AddRequestData("vnp_TmnCode", _configuration["Vnpay:TmnCode"]);
            pay.AddRequestData("vnp_Amount", ((int)model.Amount * 100).ToString());
            pay.AddRequestData("vnp_CreateDate", timeNow.ToString("yyyyMMddHHmmss"));
            pay.AddRequestData("vnp_CurrCode", _configuration["Vnpay:CurrCode"] ?? "VND");
            pay.AddRequestData("vnp_IpAddr", pay.GetIpAddress(context)); // Sử dụng hàm GetIpAddress từ VnPayLibrary
            pay.AddRequestData("vnp_Locale", locale); // 👈 Lấy locale từ tham số
            pay.AddRequestData("vnp_OrderInfo", model.OrderDescription);
            pay.AddRequestData("vnp_OrderType", model.OrderType ?? "other");
            pay.AddRequestData("vnp_ReturnUrl", urlCallBack);
            pay.AddRequestData("vnp_TxnRef", vnp_TxnRef); // 👈 Dùng OrderID

            // Thêm BankCode nếu người dùng chọn (Cách 2)
            if (bankCode != "Default" && !string.IsNullOrEmpty(bankCode))
            {
                pay.AddRequestData("vnp_BankCode", bankCode); // 👈 Thêm BankCode
            }

            var paymentUrl =
                pay.CreateRequestUrl(_configuration["Vnpay:BaseUrl"], _configuration["Vnpay:HashSecret"]);

            return paymentUrl;
        }

        public PaymentResponseModel PaymentExecute(IQueryCollection collections)
        {
            var pay = new VnPayLibrary();
            var response = pay.GetFullResponseData(collections, _configuration["Vnpay:HashSecret"]);
            return response;
        }
    }
}