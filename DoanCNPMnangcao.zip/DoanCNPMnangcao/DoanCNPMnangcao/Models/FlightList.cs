﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DoanCNPMnangcao.Models
{
    [Table("FlightList")]
    public class FlightList
    {
        [Key]
        public int FlightID { get; set; }

        [Required]
        [MaxLength(20)]
        public string FlightNumber { get; set; } = null!;

        [Required]
        [MaxLength(100)]
        public string DepartureAirport { get; set; } = null!;

        [Required]
        [MaxLength(10)]
        public string DepartureCode { get; set; } = null!;

        [Required]
        [MaxLength(100)]
        public string ArrivalAirport { get; set; } = null!;

        [Required]
        [MaxLength(10)]
        public string ArrivalCode { get; set; } = null!;

        public DateTime DepartureTime { get; set; }
        public DateTime ArrivalTime { get; set; }

        public int AvailableSeats { get; set; }

        [Column(TypeName = "decimal(18, 2)")]
        public decimal Price { get; set; }

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
        public DateTime? UpdatedDate { get; set; }
        [Timestamp] // Đánh dấu đây là cột RowVersion/Timestamp
        public byte[]? RowVersion { get; set; }
        // Navigation properties
        [InverseProperty("Flight")]
        public virtual ICollection<Ticket> DepartingTickets { get; set; } = new List<Ticket>();

        [InverseProperty("ReturnFlight")]
        public virtual ICollection<Ticket> ReturningTickets { get; set; } = new List<Ticket>();
    }
}