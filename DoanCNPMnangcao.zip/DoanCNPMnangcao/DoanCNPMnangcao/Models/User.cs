﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DoanCNPMnangcao.Models // Hoặc namespace của bạn
{
    [Table("User")]
    public class User
    {
        [Key]
        public int UserID { get; set; }

        [MaxLength(255)]
        public string? Avatar { get; set; } = "/Images/Avatars/default.png";

        [Required]
        [MaxLength(50)]
        public string Username { get; set; } = null!; // null!; nếu dùng C# 8+ và nullable context

        [Required]
        [MaxLength(100)]
        public string FullName { get; set; } = null!;

        [Required]
        [MaxLength(100)]
        [EmailAddress]
        public string Email { get; set; } = null!;

        [Required]
        [MaxLength(100)]
        public string Password { get; set; } = null!; // Nhớ hash mật khẩu!
        public bool IsActive { get; set; } = true; // Thêm thuộc tính này
        [MaxLength(15)]
        public string? PhoneNumber { get; set; }

        [Required]
        [MaxLength(20)]
        public string UserRole { get; set; } = "User";

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow; // Set default in C# too
        public DateTime? UpdatedDate { get; set; }

        // Navigation properties
        public virtual ICollection<Ticket> Tickets { get; set; } = new List<Ticket>();
        public virtual ICollection<Order> Orders { get; set; } = new List<Order>();
        public virtual ICollection<Notification> Notifications { get; set; } = new List<Notification>();
        public virtual ICollection<Feedback> Feedbacks { get; set; } = new List<Feedback>();
    }
}