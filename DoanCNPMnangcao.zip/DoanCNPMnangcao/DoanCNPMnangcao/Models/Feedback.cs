﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DoanCNPMnangcao.Models // 👈 Đảm bảo namespace này khớp với các Model khác
{
    [Table("Feedback")]
    public class Feedback
    {
        [Key]
        public int FeedbackID { get; set; }

        [Required]
        public int UserID { get; set; } // Foreign Key đến Bảng User

        [Required(ErrorMessage = "Nội dung là bắt buộc.")]
        [StringLength(1000)]
        public string Message { get; set; } = string.Empty; // 👈 SỬA: Thêm thuộc tính này

        [Range(1, 5)]
        public int Rating { get; set; } = 5; // 👈 SỬA: Thêm thuộc tính này

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow; // 👈 SỬA: Thêm thuộc tính này

        // Navigation property (Để Include thông tin User)
        [ForeignKey("UserID")]
        public virtual User? User { get; set; }
    }
}