﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DoanCNPMnangcao.Models
{
    [Table("Ticket")]
    public class Ticket
    {
        [Key]
        public int TicketID { get; set; }

        public int? UserID { get; set; } // Nullable foreign key

        [ForeignKey("UserID")]
        public virtual User? User { get; set; } // Navigation property

        public int FlightID { get; set; }

        [ForeignKey("FlightID")]
        [InverseProperty("DepartingTickets")]
        public virtual FlightList Flight { get; set; } = null!; // Chuyến bay đi (Required)

        public DateTime? BookingDate { get; set; } // Nullable

        [Required]
        [MaxLength(10)]
        public string SeatNumber { get; set; } = null!;

        [MaxLength(10)]
        public string? TicketType { get; set; } // Nullable

        [Column(TypeName = "decimal(18, 2)")]
        public decimal TicketPrice { get; set; }

        [Required]
        [MaxLength(20)]
        public string TicketStatus { get; set; } = "Queued";

        public int? ReturnFlightID { get; set; } // Nullable foreign key

        [ForeignKey("ReturnFlightID")]
        [InverseProperty("ReturningTickets")]
        public virtual FlightList? ReturnFlight { get; set; } // Chuyến bay về (Nullable)

        // Navigation property for OrderDetail
        public virtual ICollection<OrderDetail> OrderDetails { get; set; } = new List<OrderDetail>();
    }
}