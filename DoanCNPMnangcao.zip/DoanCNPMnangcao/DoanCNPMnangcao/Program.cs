﻿using Microsoft.EntityFrameworkCore;
using DoanCNPMnangcao.Data;
using DoanCNPMnangcao.Services; // 👈 1. THÊM USING
using DoanCNPMnangcao.Hubs; // 👈 THÊM USING NÀY
using Microsoft.AspNetCore.Authentication.Cookies;

var builder = WebApplication.CreateBuilder(args);

// 1. Đăng ký các dịch vụ (Services)
builder.Services.AddRazorPages();

// Đăng ký DbContext
builder.Services.AddDbContext<FlightReservationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("FlightReservationDBConnection")));

// 🚀 2. ĐĂNG KÝ VNPAY SERVICE
builder.Services.AddScoped<IVnPayService, VnPayService>();

// 3. THÊM DỊCH VỤ AUTHENTICATION
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login"; // 👈 Sửa đường dẫn nếu cần
        options.AccessDeniedPath = "/AccessDenied";
        options.ExpireTimeSpan = TimeSpan.FromDays(30);
        options.Cookie.HttpOnly = true;
        options.Cookie.IsEssential = true;
    });
builder.Services.AddSignalR(); // 👈 1. THÊM DỊCH VỤ SIGNALR
// 4. THÊM DỊCH VỤ AUTHORIZATION
builder.Services.AddAuthorization();
// --------------------------------------------------

var app = builder.Build();

// 5. Cấu hình HTTP request pipeline
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    // app.UseHsts();
}

// app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();

// 6. KÍCH HOẠT AUTHENTICATION & AUTHORIZATION
app.UseAuthentication(); // Bật Xác thực
app.UseAuthorization();  // Bật Phân quyền
// ---------------------------------------------------
app.MapGet("/api/flights/all", async (FlightReservationDbContext context) =>
{
    // Lấy tất cả các chuyến bay đang hoạt động
    var flights = await context.FlightLists
        .AsNoTracking()
        .Where(f => f.DepartureTime >= DateTime.Now.Date) // Chỉ lấy các chuyến bay chưa khởi hành
        .Select(f => new
        {
            f.FlightID,
            f.FlightNumber,
            f.DepartureCode,
            f.ArrivalCode,
            f.DepartureTime,
            f.ArrivalTime,
            f.Price,
            f.AvailableSeats
        })
        .ToListAsync();

    // Trả về kết quả dưới dạng JSON (ASP.NET Core tự động serialize)
    return Results.Ok(flights);
});

// THÊM ENDPOINT LẤY USER (Cần thiết cho mobile app)
app.MapGet("/api/users/count", async (FlightReservationDbContext context) =>
{
    var totalUsers = await context.Users.CountAsync();
    return Results.Ok(new { TotalUsers = totalUsers, Timestamp = DateTime.Now });
});
// ------------------------------------
app.MapRazorPages();
app.MapHub<BookingHub>("/bookingHub"); // 👈 2. MAP HUB ENDPOINT
app.Run();