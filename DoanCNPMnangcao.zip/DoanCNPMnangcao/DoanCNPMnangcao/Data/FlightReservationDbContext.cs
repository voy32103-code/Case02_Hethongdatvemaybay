﻿using Microsoft.EntityFrameworkCore; // <--- Dòng bạn cần thêm
using DoanCNPMnangcao.Models;

namespace DoanCNPMnangcao.Data // Đảm bảo namespace này đúng với thư mục Data của bạn
{
    public class FlightReservationDbContext : DbContext
    {
        // Constructor để nhận cấu hình từ Program.cs
        public FlightReservationDbContext(DbContextOptions<FlightReservationDbContext> options)
            : base(options)
        {
        }

        // Khai báo các DbSet tương ứng với các bảng/model
        public DbSet<User> Users { get; set; }
        public DbSet<FlightList> FlightLists { get; set; }
        public DbSet<Ticket> Tickets { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderDetail> OrderDetails { get; set; }
        public DbSet<Notification> Notifications { get; set; }
        public DbSet<Feedback> Feedbacks { get; set; }

        // Ghi đè phương thức OnModelCreating để cấu hình chi tiết (Fluent API)
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Cấu hình các thuộc tính và giá trị mặc định (đã bao gồm từ lần trước)
            modelBuilder.Entity<User>(entity =>
            {
                entity.ToTable("User"); // Đảm bảo tên bảng
                entity.Property(e => e.CreatedDate).HasDefaultValueSql("GETDATE()");
                entity.Property(e => e.UserRole).HasDefaultValue("User");
                entity.Property(e => e.Avatar).HasDefaultValue("/Images/Avatars/default.png");
            });

             modelBuilder.Entity<FlightList>(entity =>
            {
                 entity.ToTable("FlightList");
                entity.Property(e => e.CreatedDate).HasDefaultValueSql("GETDATE()");
            });

             modelBuilder.Entity<Ticket>(entity =>
            {
                 entity.ToTable("Ticket");
                // Chỉ định mối quan hệ phức tạp của FlightID và ReturnFlightID
                entity.HasOne(t => t.Flight)
                      .WithMany(f => f.DepartingTickets)
                      .HasForeignKey(t => t.FlightID)
                      .OnDelete(DeleteBehavior.Restrict); // Ngăn xóa Flight nếu có Ticket

                entity.HasOne(t => t.ReturnFlight)
                      .WithMany(f => f.ReturningTickets)
                      .HasForeignKey(t => t.ReturnFlightID)
                      .OnDelete(DeleteBehavior.Restrict); // Ngăn xóa Flight nếu có Ticket

                entity.Property(e => e.TicketStatus).HasDefaultValue("Queued");
            });

             modelBuilder.Entity<Order>(entity =>
            {
                 entity.ToTable("Order");
                 entity.Property(e => e.OrderDate).HasDefaultValueSql("GETDATE()");
                 entity.Property(e => e.PaymentStatus).HasDefaultValue("Pending");
                 entity.Property(e => e.OrderStatus).HasDefaultValue("Pending");
                 entity.Property(e => e.CreatedDate).HasDefaultValueSql("GETDATE()");
            });

             modelBuilder.Entity<OrderDetail>(entity =>
             {
                 entity.ToTable("OrderDetail");
                 entity.Property(e => e.Quantity).HasDefaultValue(1);
                 entity.Property(e => e.Discount).HasDefaultValue(0.00m);
                 entity.Property(e => e.TotalPrice)
                       .HasComputedColumnSql("([Quantity] * [UnitPrice] - [Discount])", stored: true);
                 entity.Property(e => e.CreatedDate).HasDefaultValueSql("GETDATE()");
             });

            modelBuilder.Entity<Notification>(entity =>
            {
                 entity.ToTable("Notification");
                entity.Property(e => e.CreatedDate).HasDefaultValueSql("GETDATE()");
                entity.Property(e => e.IsRead).HasDefaultValue(false);
            });

            modelBuilder.Entity<Feedback>(entity =>
            {
                 entity.ToTable("Feedback");
                entity.HasOne(f => f.User)
                      .WithMany(u => u.Feedbacks)
                      .HasForeignKey(f => f.UserID)
                      .OnDelete(DeleteBehavior.SetNull); // Hoặc Cascade/Restrict tùy logic
            });
        }
    }
}